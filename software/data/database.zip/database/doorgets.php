a:57:{s:12:"_dg_firewall";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:338:" DROP TABLE IF EXISTS `_dg_firewall`;
    
    CREATE TABLE IF NOT EXISTS `_dg_firewall` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `adresse_ip` varchar(255) DEFAULT NULL,
        `level` int(11) DEFAULT '1',
        `date_creation` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ; ";}s:9:"_dg_block";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:454:" DROP TABLE IF EXISTS `_dg_block`;
    
    CREATE TABLE IF NOT EXISTS `_dg_block` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `uri` varchar(255) DEFAULT NULL,
        `groupe_traduction` text,
        `date_creation` int(11) DEFAULT NULL,
        `date_modification` int(11) DEFAULT NULL,
        `id_user` int(11) DEFAULT NULL,
        `id_groupe` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ; ";}s:20:"_dg_block_traduction";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:535:" 
    
    DROP TABLE IF EXISTS `_dg_block_traduction`;
    CREATE TABLE IF NOT EXISTS `_dg_block_traduction` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_block` int(11) DEFAULT NULL,
        `uri_module` varchar(255) DEFAULT NULL,
        `langue` varchar(255) DEFAULT NULL,
        `titre` varchar(255) DEFAULT NULL,
        `description` varchar(255) DEFAULT NULL,
        `article_tinymce` text,
        `date_modification` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ; ";}s:12:"_dg_carousel";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:460:" DROP TABLE IF EXISTS `_dg_carousel`;
    
    CREATE TABLE IF NOT EXISTS `_dg_carousel` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `uri` varchar(255) DEFAULT NULL,
        `groupe_traduction` text,
        `date_creation` int(11) DEFAULT NULL,
        `date_modification` int(11) DEFAULT NULL,
        `id_user` int(11) DEFAULT NULL,
        `id_groupe` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ; ";}s:23:"_dg_carousel_traduction";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:544:" 
    
    DROP TABLE IF EXISTS `_dg_carousel_traduction`;
    CREATE TABLE IF NOT EXISTS `_dg_carousel_traduction` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_carousel` int(11) DEFAULT NULL,
        `uri_module` varchar(255) DEFAULT NULL,
        `langue` varchar(255) DEFAULT NULL,
        `titre` varchar(255) DEFAULT NULL,
        `description` varchar(255) DEFAULT NULL,
        `article_tinymce` text,
        `date_modification` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ; ";}s:9:"_dg_inbox";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:687:" DROP TABLE IF EXISTS `_dg_inbox`;
    CREATE TABLE IF NOT EXISTS `_dg_inbox` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `uri_module` varchar(255) DEFAULT NULL,
        `sujet` varchar(255) NOT NULL,
        `nom` varchar(255) DEFAULT NULL,
        `email` varchar(255) DEFAULT NULL,
        `message` text,
        `telephone` varchar(255) DEFAULT NULL,
        `lu` int(11) NOT NULL DEFAULT '0',
        `archive` int(11) NOT NULL DEFAULT '0',
        `date_creation` int(11) NOT NULL DEFAULT '0',
        `date_archive` int(11) NOT NULL DEFAULT '0',
        `date_lu` int(11) NOT NULL DEFAULT '0',
        PRIMARY KEY (`id`)
      ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:9:"_dg_links";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:470:" DROP TABLE IF EXISTS `_dg_links`;
    CREATE TABLE IF NOT EXISTS `_dg_links` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `langue` varchar(255) DEFAULT NULL,
        `uri_module` varchar(255) DEFAULT NULL,
        `label` varchar(255) DEFAULT NULL,
        `link` varchar(255) DEFAULT NULL,
        `date_creation` int(11) DEFAULT NULL,
        `date_modification` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:14:"_dg_newsletter";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:552:" DROP TABLE IF EXISTS `_dg_newsletter`;
    CREATE TABLE IF NOT EXISTS `_dg_newsletter` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_user` int(11) NOT NULL DEFAULT '0',
        `id_groupe` int(11) NOT NULL DEFAULT '0',
        `nom` varchar(255) DEFAULT NULL,
        `email` varchar(255) DEFAULT NULL,
        `description` text,
        `newsletter` int(11) DEFAULT '1',
        `client_ip` varchar(255) DEFAULT NULL,
        `date_creation` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:33:"_dg_newsletter_emailling_campagne";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:723:" DROP TABLE IF EXISTS `_dg_newsletter_emailling_campagne`;
    CREATE TABLE IF NOT EXISTS `_dg_newsletter_emailling_campagne` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_user` int(11) DEFAULT NULL,
        `id_user_groupe` int(11) DEFAULT NULL,
        `id_groupe` int(11) NOT NULL,
        `id_models` int(11) NOT NULL,
        `statut` varchar(255) NOT NULL,
        `titre` text NOT NULL,
        `description` text NOT NULL,
        `message` text,
        `date_creation` int(11) DEFAULT '0',
        `date_modification` int(11) DEFAULT '0',
        `date_validation` int(11) DEFAULT '0',
        `date_envoi` int(11) DEFAULT '0',
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:31:"_dg_newsletter_emailling_groupe";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:409:" DROP TABLE IF EXISTS `_dg_newsletter_emailling_groupe`;
    CREATE TABLE IF NOT EXISTS `_dg_newsletter_emailling_groupe` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `titre` varchar(255) DEFAULT NULL,
        `description` text NOT NULL,
        `date_creation` int(11) NOT NULL,
        `date_modification` int(11) NOT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:31:"_dg_newsletter_emailling_models";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:571:" DROP TABLE IF EXISTS `_dg_newsletter_emailling_models`;
    CREATE TABLE IF NOT EXISTS `_dg_newsletter_emailling_models` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `titre` varchar(255) DEFAULT NULL,
        `description` text,
        `langue` varchar(255) DEFAULT NULL,
        `format` varchar(255) DEFAULT NULL,
        `sujet` varchar(255) DEFAULT NULL,
        `article_tinymce` text,
        `date_creation` int(11) DEFAULT NULL,
        `date_modification` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:8:"_dg_page";a:3:{s:5:"count";i:2;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:1016:" DROP TABLE IF EXISTS `_dg_page`;
    CREATE TABLE IF NOT EXISTS `_dg_page` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_user` int(11) DEFAULT '0',
        `id_groupe` int(11) DEFAULT '0',
        `uri` varchar(255) DEFAULT NULL,
        `active` int(11) NOT NULL DEFAULT '0',
        `comments` int(11) NOT NULL DEFAULT '0',
        `partage` int(11) NOT NULL DEFAULT '1',
        `facebook` int(11) DEFAULT '0',
        `id_facebook` varchar(255) DEFAULT NULL,
        `disqus` int(11) DEFAULT '0',
        `id_disqus` varchar(255) DEFAULT NULL,
        `mailsender` int(11) DEFAULT '0',
        `sendto` varchar(255) DEFAULT NULL,
        `in_rss` int(11) NOT NULL DEFAULT '0',
        `ordre` int(11) NOT NULL DEFAULT '0',
        `groupe_traduction` text,
        `date_creation` int(11) DEFAULT NULL,
        `id_modo` int(111) DEFAULT NULL,
        `val_modo` int(11) DEFAULT '0',
        `date_modo` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:19:"_dg_page_traduction";a:3:{s:5:"count";i:40;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:1222:" DROP TABLE IF EXISTS `_dg_page_traduction`;
    CREATE TABLE IF NOT EXISTS `_dg_page_traduction` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_content` int(11) NOT NULL DEFAULT '0',
        `langue` varchar(255) DEFAULT NULL,
        `titre` varchar(255) DEFAULT NULL,
        `description` text,
        `article_tinymce` text,
        `uri` varchar(255) DEFAULT NULL,
        `uri_module` varchar(255) DEFAULT NULL,
        `meta_titre` varchar(255) DEFAULT NULL,
        `meta_description` varchar(255) DEFAULT NULL,
        `meta_keys` varchar(255) DEFAULT NULL,
        `meta_facebook_type` varchar(255) DEFAULT NULL,
        `meta_facebook_titre` varchar(255) DEFAULT NULL,
        `meta_facebook_description` varchar(255) DEFAULT NULL,
        `meta_facebook_image` varchar(255) DEFAULT NULL,
        `meta_twitter_type` varchar(255) DEFAULT NULL,
        `meta_twitter_titre` varchar(255) DEFAULT NULL,
        `meta_twitter_description` varchar(255) DEFAULT NULL,
        `meta_twitter_image` varchar(255) DEFAULT NULL,
        `meta_twitter_player` varchar(255) DEFAULT NULL,
        `date_modification` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:16:"_dg_page_version";a:3:{s:5:"count";i:69;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:1374:" DROP TABLE IF EXISTS `_dg_page_version`;
    CREATE TABLE IF NOT EXISTS `_dg_page_version` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `active` int(11) DEFAULT '0',
        `id_content` int(11) NOT NULL DEFAULT '0',
        `pseudo` varchar(255) DEFAULT NULL,
        `id_user` int(11) DEFAULT '0',
        `id_groupe` int(11) DEFAULT '0',
        `langue` varchar(255) DEFAULT NULL,
        `titre` varchar(255) DEFAULT NULL,
        `description` text,
        `article_tinymce` text,
        `uri` varchar(255) DEFAULT NULL,
        `uri_module` varchar(255) DEFAULT NULL,
        `meta_titre` varchar(255) DEFAULT NULL,
        `meta_description` varchar(255) DEFAULT NULL,
        `meta_keys` varchar(255) DEFAULT NULL,
        `meta_facebook_type` varchar(255) DEFAULT NULL,
        `meta_facebook_titre` varchar(255) DEFAULT NULL,
        `meta_facebook_description` varchar(255) DEFAULT NULL,
        `meta_facebook_image` varchar(255) DEFAULT NULL,
        `meta_twitter_type` varchar(255) DEFAULT NULL,
        `meta_twitter_titre` varchar(255) DEFAULT NULL,
        `meta_twitter_description` varchar(255) DEFAULT NULL,
        `meta_twitter_image` varchar(255) DEFAULT NULL,
        `meta_twitter_player` varchar(255) DEFAULT NULL,
        `date_creation` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:9:"_dg_files";a:3:{s:5:"count";i:1;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:435:" DROP TABLE IF EXISTS `_dg_files`;
    CREATE TABLE IF NOT EXISTS `_dg_files` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_user` int(11) DEFAULT '0',
        `id_groupe` int(11) DEFAULT '0',
        `uri` varchar(255) DEFAULT NULL,
        `type` varchar(255) NOT NULL,
        `groupe_traduction` text,
        `date_creation` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ; ";}s:20:"_dg_files_traduction";a:3:{s:5:"count";i:20;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:476:" DROP TABLE IF EXISTS `_dg_files_traduction`;
    CREATE TABLE IF NOT EXISTS `_dg_files_traduction` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_file` int(11) DEFAULT '0',
        `langue` varchar(11) DEFAULT '0',
        `title` varchar(255) DEFAULT NULL,
        `path` varchar(255) DEFAULT NULL,
        `size` varchar(255) DEFAULT NULL,
        `date_modification` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ; ";}s:14:"_dg_translator";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:392:" DROP TABLE IF EXISTS `_dg_translator`;
    CREATE TABLE IF NOT EXISTS `_dg_translator` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_user` int(11) DEFAULT '0',
        `id_groupe` int(11) DEFAULT '0',
        `sentence`  text,
        `groupe_traduction` text,
        `date_creation` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ; ";}s:25:"_dg_translator_traduction";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:446:" DROP TABLE IF EXISTS `_dg_translator_traduction`;
    CREATE TABLE IF NOT EXISTS `_dg_translator_traduction` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_translator` int(11) DEFAULT '0',
        `langue` varchar(11) DEFAULT '0',
        `translated_sentence` text,
        `is_translated` int(11) DEFAULT '0',
        `date_modification` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ; ";}s:22:"_dg_translator_version";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:568:" DROP TABLE IF EXISTS `_dg_translator_version`;
    CREATE TABLE IF NOT EXISTS `_dg_translator_version` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_content` int(11) NOT NULL DEFAULT '0',
        `pseudo` varchar(255) DEFAULT NULL,
        `id_user` int(11) DEFAULT '0',
        `id_groupe` int(11) DEFAULT '0',
        `langue` varchar(255) DEFAULT NULL,
        `translated_sentence` text,
        `is_translated` int(11) DEFAULT '0',
        `date_creation` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ; ";}s:22:"_dg_email_notification";a:3:{s:5:"count";i:3;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:411:" DROP TABLE IF EXISTS `_dg_email_notification`;
    CREATE TABLE `_dg_email_notification` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `id_user` int(11) DEFAULT '0',
      `id_groupe` int(11) DEFAULT '0',
      `uri` varchar(255) DEFAULT NULL,
      `groupe_traduction` text,
      `date_creation` int(11) DEFAULT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8; ";}s:33:"_dg_email_notification_traduction";a:3:{s:5:"count";i:60;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:524:" DROP TABLE IF EXISTS `_dg_email_notification_traduction`;
    CREATE TABLE `_dg_email_notification_traduction` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `id_content` int(11) DEFAULT '0',
      `title` varchar(255) DEFAULT NULL,
      `langue` varchar(11) DEFAULT NULL,
      `type` varchar(11) DEFAULT NULL,
      `subject` varchar(255) DEFAULT NULL,
      `message_tinymce` text,
      `date_modification` int(11) DEFAULT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8; ";}s:30:"_dg_email_notification_version";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:642:" DROP TABLE IF EXISTS `_dg_email_notification_version`;
    CREATE TABLE `_dg_email_notification_version` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `id_content` int(11) NOT NULL DEFAULT '0',
      `title` varchar(255) DEFAULT NULL,
      `pseudo` varchar(255) DEFAULT NULL,
      `id_user` int(11) DEFAULT '0',
      `id_groupe` int(11) DEFAULT '0',
      `langue` varchar(255) DEFAULT NULL,
      `type` varchar(11) DEFAULT NULL,
      `subject` varchar(255) DEFAULT NULL,
      `message_tinymce` text,
      `date_creation` int(11) DEFAULT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8; ";}s:11:"_categories";a:3:{s:5:"count";i:2;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:417:" DROP TABLE IF EXISTS `_categories`;
    CREATE TABLE IF NOT EXISTS `_categories` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_parent` int(11) NOT NULL DEFAULT '0',
        `uri_module` varchar(255) DEFAULT NULL,
        `groupe_traduction` text,
        `ordre` int(11) DEFAULT NULL,
        `date_creation` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:22:"_categories_traduction";a:3:{s:5:"count";i:40;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:670:" DROP TABLE IF EXISTS `_categories_traduction`;
    CREATE TABLE IF NOT EXISTS `_categories_traduction` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_cat` int(11) NOT NULL DEFAULT '0',
        `langue` varchar(10) NOT NULL DEFAULT 'fr',
        `nom` varchar(255) DEFAULT NULL,
        `titre` varchar(255) DEFAULT NULL,
        `description` text,
        `uri` varchar(255) DEFAULT NULL,
        `meta_titre` varchar(255) DEFAULT NULL,
        `meta_description` varchar(255) DEFAULT NULL,
        `meta_keys` varchar(255) DEFAULT NULL,
        `date_creation` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:12:"_dg_comments";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:902:" DROP TABLE IF EXISTS `_dg_comments`;   
    CREATE TABLE IF NOT EXISTS `_dg_comments` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_user` int(11) DEFAULT '0',
        `id_groupe` int(11) DEFAULT '0',
        `uri_module` varchar(255) DEFAULT NULL,
        `uri_content` varchar(255) DEFAULT NULL,
        `nom` varchar(255) DEFAULT NULL,
        `email` varchar(255) DEFAULT NULL,
        `url` varchar(255) DEFAULT NULL,
        `comment` text,
        `lu` int(11) NOT NULL DEFAULT '0',
        `archive` int(11) NOT NULL DEFAULT '0',
        `date_creation` int(11) DEFAULT NULL,
        `validation` int(11) DEFAULT '0',
        `date_validation` int(11) DEFAULT '0',
        `date_archive` int(11) NOT NULL DEFAULT '0',
        `adress_ip` varchar(255) DEFAULT NULL,
        `langue` varchar(255) DEFAULT 'en',
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:11:"_moderation";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:599:"DROP TABLE IF EXISTS `_moderation`;
    CREATE TABLE IF NOT EXISTS `_moderation` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_user` int(11) DEFAULT NULL,
        `pseudo` varchar(255) DEFAULT NULL,
        `id_groupe` int(11) DEFAULT NULL,
        `id_content` int(11) DEFAULT NULL,
        `uri_module` varchar(255) DEFAULT NULL,
        `type_module` varchar(255) DEFAULT NULL,
        `action` varchar(255) DEFAULT NULL,
        `langue` varchar(10) DEFAULT NULL,
        `date_creation` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:8:"_modules";a:3:{s:5:"count";i:5;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:1375:" DROP TABLE IF EXISTS `_modules`; 
    CREATE TABLE IF NOT EXISTS `_modules` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `type` varchar(255) DEFAULT NULL,
        `uri` varchar(255) DEFAULT NULL,
        `active` int(11) DEFAULT '1',
        `author_badge` int(11) DEFAULT '0',
        `is_first` int(11) DEFAULT '0',
        `plugins` text,
        `groupe_traduction` text,
        `bynum` int(11) DEFAULT '10',
        `avoiraussi` int(11) NOT NULL DEFAULT '3',
        `image` varchar(255) DEFAULT NULL,
        `template_index` varchar(255) DEFAULT NULL,
        `template_content` varchar(255) DEFAULT NULL,
        `notification_mail` int(11) NOT NULL DEFAULT '1',
        `uri_notification_moderator` varchar(255) DEFAULT NULL,
        `uri_notification_user_success` varchar(255) DEFAULT NULL,
        `uri_notification_user_error` varchar(255) DEFAULT NULL,
        `extras` text,
        `redirection` varchar(255) DEFAULT NULL,
        `recaptcha` int(11) NOT NULL DEFAULT '0',
        `with_password` int(11) NOT NULL DEFAULT '0',
        `password` varchar(255) DEFAULT NULL,
        `public_module` int(11) NOT NULL DEFAULT '0',
        `public_comment` int(11) NOT NULL DEFAULT '0',
        `public_add` int(11) NOT NULL DEFAULT '0',
        `date_creation` int(11) NOT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:19:"_modules_traduction";a:3:{s:5:"count";i:99;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:1509:" DROP TABLE IF EXISTS `_modules_traduction`;
    CREATE TABLE IF NOT EXISTS `_modules_traduction` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_module` int(11) DEFAULT NULL,
        `langue` varchar(255) DEFAULT NULL,
        `nom` varchar(255) DEFAULT NULL,
        `titre` varchar(255) DEFAULT NULL,
        `description` text,
        `send_mail_to` varchar(255) DEFAULT NULL,
        `top_tinymce` text,
        `bottom_tinymce` text,
        `extras` text,
        `send_mail_user` varchar(255) DEFAULT NULL,
        `send_mail_name` varchar(255) DEFAULT NULL,
        `send_mail_email` varchar(255) DEFAULT NULL,
        `send_mail_sujet` varchar(255) DEFAULT NULL,
        `send_mail_message` text,
        `meta_titre` varchar(255) DEFAULT NULL,
        `meta_description` varchar(255) DEFAULT NULL,
        `meta_keys` varchar(255) DEFAULT NULL,
        `meta_facebook_type` varchar(255) DEFAULT NULL,
        `meta_facebook_titre` varchar(255) DEFAULT NULL,
        `meta_facebook_description` varchar(255) DEFAULT NULL,
        `meta_facebook_image` varchar(255) DEFAULT NULL,
        `meta_twitter_type` varchar(255) DEFAULT NULL,
        `meta_twitter_titre` varchar(255) DEFAULT NULL,
        `meta_twitter_description` varchar(255) DEFAULT NULL,
        `meta_twitter_image` varchar(255) DEFAULT NULL,
        `meta_twitter_player` varchar(255) DEFAULT NULL,
        `date_modification` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:9:"_rubrique";a:3:{s:5:"count";i:8;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:454:" DROP TABLE IF EXISTS `_rubrique`;
    CREATE TABLE IF NOT EXISTS `_rubrique` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `name` varchar(220) DEFAULT NULL,
        `ordre` int(11) DEFAULT NULL,
        `idModule` int(11) NOT NULL DEFAULT '0',
        `idParent` int(11) DEFAULT '0',
        `showinmenu` int(11) DEFAULT '1',
        `date_creation` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:15:"_rubrique_users";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:466:" DROP TABLE IF EXISTS `_rubrique_users`;
    CREATE TABLE IF NOT EXISTS `_rubrique_users` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `name` varchar(220) DEFAULT NULL,
        `ordre` int(11) DEFAULT NULL,
        `idModule` int(11) NOT NULL DEFAULT '0',
        `idParent` int(11) DEFAULT '0',
        `showinmenu` int(11) DEFAULT '1',
        `date_creation` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:6:"_users";a:3:{s:5:"count";i:1;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:365:" DROP TABLE IF EXISTS `_users`;
    CREATE TABLE IF NOT EXISTS `_users` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `login` varchar(255) DEFAULT NULL,
        `password` varchar(255) DEFAULT NULL,
        `token` varchar(255) DEFAULT NULL,
        `salt` varchar(255) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:17:"_users_activation";a:3:{s:5:"count";i:3;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:422:" DROP TABLE IF EXISTS `_users_activation`;
    CREATE TABLE IF NOT EXISTS `_users_activation` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `type` varchar(255) NOT NULL,
        `id_user` int(11) DEFAULT NULL,
        `code` varchar(255) DEFAULT NULL,
        `email` varchar(255) DEFAULT NULL,
        `date_creation` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:16:"_users_followers";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:344:" DROP TABLE IF EXISTS `_users_followers`;
    CREATE TABLE IF NOT EXISTS `_users_followers` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_user` int(11) DEFAULT NULL,
        `id_user_follow` int(11) DEFAULT NULL,
        `date_creation` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:12:"_users_track";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:701:" DROP TABLE IF EXISTS `_users_track`;
    CREATE TABLE IF NOT EXISTS `_users_track` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_session` varchar(255) DEFAULT NULL,
        `id_user` int(11) NOT NULL,
        `id_groupe` int(11) NOT NULL,
        `title` varchar(255) DEFAULT NULL,
        `langue` varchar(255) DEFAULT NULL,
        `uri_module` varchar(255) NOT NULL,
        `id_content` text NOT NULL,
        `action` varchar(255) NOT NULL,
        `ip_user` varchar(255) NOT NULL,
        `url_page` varchar(255) DEFAULT NULL,
        `url_referer` varchar(255) DEFAULT NULL,
        `date` int(11) NOT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:19:"_users_notification";a:3:{s:5:"count";i:496;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:523:" DROP TABLE IF EXISTS `_users_notification`;
    CREATE TABLE IF NOT EXISTS `_users_notification` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_user` int(11) DEFAULT NULL,
        `id_groupe` int(11) NOT NULL,
        `id_session` varchar(255) DEFAULT NULL,
        `ip_session` varchar(255) DEFAULT NULL,
        `url_page` varchar(255) DEFAULT NULL,
        `url_referer` varchar(255) DEFAULT NULL,
        `date` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:14:"_users_groupes";a:3:{s:5:"count";i:3;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:1273:" DROP TABLE IF EXISTS `_users_groupes`;
    CREATE TABLE IF NOT EXISTS `_users_groupes` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `uri` varchar(255) DEFAULT NULL,
        `liste_widget` text,
        `liste_module` text,
        `liste_module_limit` text,
        `liste_module_list` text,
        `liste_module_show` text,
        `liste_module_add` text,
        `liste_module_edit` text,
        `liste_module_delete` text,
        `liste_module_admin` text,
        `liste_module_modo` text,
        `liste_module_interne` text,
        `liste_module_interne_modo` text,
        `liste_enfant` text,
        `liste_enfant_modo` text,
        `liste_parent` text,
        `can_subscribe` int(11) DEFAULT '1',
        `editor_ckeditor` int(1) DEFAULT '0',
        `editor_tinymce` int(1) DEFAULT '0',
        `groupe_traduction` text,
        `attributes` text,
        `saas_options` text,
        `payment` int(11) DEFAULT '0',
        `payment_amount_month` int(11) DEFAULT NULL,
        `payment_group_expired` int(11) DEFAULT NULL,
        `payment_tranche` int(11) DEFAULT NULL,
        `payment_group_upgrade` int(11) DEFAULT NULL,
        `date_creation` int(255) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:32:"_users_groupes_attributes_values";a:3:{s:5:"count";i:1;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:447:" DROP TABLE IF EXISTS `_users_groupes_attributes_values`;
    CREATE TABLE IF NOT EXISTS `_users_groupes_attributes_values` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_user` int(11) NOT NULL,
        `id_attribute` int(11) NOT NULL,
        `value` text NOT NULL,
        `date_creation` int(11) DEFAULT NULL,
        `date_modification` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:25:"_users_groupes_traduction";a:3:{s:5:"count";i:60;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:407:" DROP TABLE IF EXISTS `_users_groupes_traduction`;
    CREATE TABLE IF NOT EXISTS `_users_groupes_traduction` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_groupe` int(11) DEFAULT NULL,
        `langue` varchar(255) DEFAULT NULL,
        `title` varchar(255) DEFAULT NULL,
        `description` varchar(255) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:19:"_users_access_token";a:3:{s:5:"count";i:7;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:387:" DROP TABLE IF EXISTS `_users_access_token`;
    CREATE TABLE IF NOT EXISTS `_users_access_token` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_user` int(11) DEFAULT NULL,
        `token` varchar(255) DEFAULT NULL,
        `is_valid` int(11) DEFAULT NULL,
        `date_creation` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:12:"_users_inbox";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:899:" DROP TABLE IF EXISTS `_users_inbox`;
    CREATE TABLE IF NOT EXISTS `_users_inbox` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_user` int(11) DEFAULT NULL,
        `id_user_sent` int(11) DEFAULT NULL,
        `pseudo_user` varchar(255) DEFAULT NULL,
        `pseudo_user_sent` varchar(255) DEFAULT NULL,
        `user_delete` int(1) DEFAULT '0',
        `user_sent_delete` int(1) DEFAULT '0',
        `name` varchar(255) DEFAULT NULL,
        `email` varchar(255) DEFAULT NULL,
        `phone` varchar(255) DEFAULT NULL,
        `subject` varchar(255) DEFAULT NULL,
        `message` text,
        `readed` int(1) DEFAULT '0',
        `date_readed` int(11) DEFAULT NULL,
        `date_deleted` int(11) DEFAULT NULL,
        `date_sent_deleted` int(11) DEFAULT NULL,
        `date_creation` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:11:"_users_info";a:3:{s:5:"count";i:1;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:1751:" DROP TABLE IF EXISTS `_users_info`;
    CREATE TABLE IF NOT EXISTS `_users_info` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `profile_type` int(11) DEFAULT '1',
        `active` int(11) DEFAULT '0',
        `id_user` int(11) DEFAULT NULL,
        `langue` varchar(255) DEFAULT NULL,
        `network` int(11) DEFAULT NULL,
        `email` varchar(255) DEFAULT NULL,
        `pseudo` varchar(255) DEFAULT NULL,
        `last_name` varchar(255) DEFAULT NULL,
        `first_name` varchar(255) DEFAULT NULL,
        `country` varchar(255) DEFAULT NULL,
        `city` varchar(255) DEFAULT NULL,
        `zipcode` varchar(255) DEFAULT NULL,
        `adresse` varchar(255) DEFAULT NULL,
        `tel_fix` varchar(255) DEFAULT NULL,
        `tel_mobil` varchar(255) DEFAULT NULL,
        `tel_fax` varchar(255) DEFAULT NULL,
        `id_facebook` varchar(255) DEFAULT NULL,
        `id_twitter` varchar(255) DEFAULT NULL,
        `id_google` varchar(255) DEFAULT NULL,
        `id_linkedin` varchar(255) DEFAULT NULL,
        `id_pinterest` varchar(255) DEFAULT NULL,
        `id_myspace` varchar(255) DEFAULT NULL,
        `id_youtube` varchar(255) DEFAULT NULL,
        `notification_mail` int(1) DEFAULT '1',
        `notification_newsletter` int(1) DEFAULT '1',
        `birthday` varchar(255) DEFAULT NULL,
        `gender` varchar(255) DEFAULT NULL,
        `avatar` varchar(255) DEFAULT NULL,
        `description` text,
        `website` varchar(255) DEFAULT NULL,
        `horaire` varchar(255) DEFAULT 'Europe/London',
        `editor_html` varchar(50) DEFAULT NULL,
        `date_creation` int(11) DEFAULT NULL,
        `date_modification` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:14:"_user_facebook";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:895:" DROP TABLE IF EXISTS `_user_facebook`;
    CREATE TABLE IF NOT EXISTS `_user_facebook` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_user` int(11) DEFAULT NULL,
        `id_facebook` varchar(255) DEFAULT NULL,
        `name` varchar(255) DEFAULT NULL,
        `email` varchar(255) DEFAULT NULL,
        `first_name` varchar(255) DEFAULT NULL,
        `middle_name` varchar(255) DEFAULT NULL,
        `last_name` varchar(255) DEFAULT NULL,
        `gender` varchar(255) DEFAULT NULL,
        `link` varchar(255) DEFAULT NULL,
        `birthday` varchar(255) DEFAULT NULL,
        `location` varchar(255) DEFAULT NULL,
        `timezone` varchar(255) DEFAULT NULL,
        `access_token` varchar(255) DEFAULT NULL,
        `date_creation` int(11) DEFAULT NULL,
        `date_modification` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:12:"_user_google";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:922:" DROP TABLE IF EXISTS `_user_google`;
    CREATE TABLE IF NOT EXISTS `_user_google` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_user` int(11) DEFAULT NULL,
        `id_google` varchar(255) DEFAULT NULL,
        `email` varchar(255) DEFAULT NULL,
        `verified_email` varchar(255) DEFAULT NULL,
        `name` varchar(255) DEFAULT NULL,
        `given_name` varchar(255) DEFAULT NULL,
        `family_name` varchar(255) DEFAULT NULL,
        `link` varchar(255) DEFAULT NULL,
        `picture` varchar(255) DEFAULT NULL,
        `gender` varchar(255) DEFAULT NULL,
        `locale` varchar(255) DEFAULT NULL,
        `access_token` varchar(255) DEFAULT NULL,
        `refresh_token` varchar(255) DEFAULT NULL,
        `user_data` text,
        `date_creation` int(11) DEFAULT NULL,
        `date_modification` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:12:"_user_stripe";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:402:" DROP TABLE IF EXISTS `_user_stripe`;
    CREATE TABLE IF NOT EXISTS `_user_stripe` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_stripe` varchar(255) DEFAULT NULL,
        `id_user` int(11) DEFAULT NULL,
        `date_creation` int(11) DEFAULT NULL,
        `date_modification` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0; ";}s:24:"_user_stripe_order_items";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:723:" DROP TABLE IF EXISTS `_user_stripe_order_items`;
    CREATE TABLE IF NOT EXISTS `_user_stripe_order_items` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_order` int(11) DEFAULT NULL,
        `type_order` int(11) DEFAULT NULL,
        `uri_module` varchar(255) DEFAULT NULL,
        `id_content` int(11) DEFAULT NULL,
        `real_amount` int(11) DEFAULT NULL,
        `title` int(11) DEFAULT NULL,
        `total_amount` int(11) DEFAULT NULL,
        `quantity` int(11) DEFAULT NULL,
        `discount` int(11) DEFAULT NULL,
        `date_creation` int(11) DEFAULT NULL,
        `date_modification` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0; ";}s:18:"_user_stripe_order";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:403:" DROP TABLE IF EXISTS `_user_stripe_order`;
    CREATE TABLE IF NOT EXISTS `_user_stripe_order` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_user` int(11) DEFAULT NULL,
        `vat` int(11) DEFAULT NULL,
        `date_creation` int(11) DEFAULT NULL,
        `date_modification` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0; ";}s:19:"_user_stripe_charge";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:659:" DROP TABLE IF EXISTS `_user_stripe_charge`;
    CREATE TABLE IF NOT EXISTS `_user_stripe_charge` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_user` int(11) DEFAULT NULL,
        `id_stripe` varchar(255) DEFAULT NULL,
        `id_charge` varchar(255) DEFAULT NULL,
        `id_order` varchar(255) DEFAULT NULL,
        `status` varchar(255) DEFAULT NULL,
        `amount` int(11) DEFAULT NULL,
        `currency` varchar(255) DEFAULT NULL,
        `data` text,
        `date_creation` int(11) DEFAULT NULL,
        `date_modification` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0; ";}s:8:"_website";a:3:{s:5:"count";i:1;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:3028:"  DROP TABLE IF EXISTS `_website`;
    CREATE TABLE IF NOT EXISTS `_website` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `statut` int(11) DEFAULT '1',
        `statut_version` int(11) DEFAULT '0',
        `statut_ip` varchar(255) DEFAULT NULL,
        `version_doorgets` varchar(255) DEFAULT NULL,
        `title` varchar(220) NOT NULL,
        `slogan` varchar(180) DEFAULT NULL,
        `copyright` varchar(100) NOT NULL,
        `year` varchar(10) NOT NULL,
        `description` varchar(220) NOT NULL,
        `keywords` varchar(220) NOT NULL,
        `email` varchar(80) DEFAULT NULL,
        `pays` varchar(180) DEFAULT NULL,
        `ville` varchar(180) DEFAULT NULL,
        `adresse` varchar(220) DEFAULT NULL,
        `codepostal` varchar(25) DEFAULT NULL,
        `tel_fix` varchar(30) DEFAULT NULL,
        `tel_mobil` varchar(30) DEFAULT NULL,
        `tel_fax` varchar(30) DEFAULT NULL,
        `facebook` varchar(120) DEFAULT NULL,
        `twitter` varchar(120) DEFAULT NULL,
        `pinterest` varchar(255) DEFAULT NULL,
        `myspace` varchar(255) DEFAULT NULL,
        `linkedin` varchar(255) DEFAULT NULL,
        `youtube` varchar(120) DEFAULT NULL,
        `google` varchar(250) DEFAULT NULL,
        `analytics` varchar(50) DEFAULT NULL,
        `langue` varchar(255) DEFAULT 'fr',
        `langue_front` varchar(255) DEFAULT 'fr',
        `langue_groupe` text,
        `horaire` varchar(255) DEFAULT 'Europe/Paris',
        `mentions` int(11) DEFAULT '1',
        `cgu` int(11) DEFAULT '1',
        `m_newsletter` int(1) DEFAULT '1',
        `m_comment` int(11) DEFAULT '1',
        `m_comment_facebook` int(11) DEFAULT '0',
        `m_comment_disqus` int(11) DEFAULT '0',
        `m_sharethis` int(11) DEFAULT '1',
        `m_sitemap` int(11) DEFAULT '1',
        `m_rss` int(11) DEFAULT '1',
        `id_facebook` varchar(255) DEFAULT NULL,
        `id_disqus` varchar(255) DEFAULT NULL,
        `theme` varchar(255) NOT NULL DEFAULT 'doorgets',
        `module_homepage` varchar(255) DEFAULT NULL,
        `oauth_google_id` varchar(255) DEFAULT NULL,
        `oauth_google_secret` varchar(255) DEFAULT NULL,
        `oauth_google_active` int(11) DEFAULT '0',
        `oauth_facebook_id` varchar(255) DEFAULT NULL,
        `oauth_facebook_secret` varchar(255) DEFAULT NULL,
        `oauth_facebook_active` int(11) DEFAULT '0',
        `smtp_mandrill_active` int(11) DEFAULT '0',
        `smtp_mandrill_host` varchar(255) DEFAULT NULL,
        `smtp_mandrill_port` varchar(255) DEFAULT NULL,
        `smtp_mandrill_username` varchar(255) DEFAULT NULL,
        `smtp_mandrill_password` varchar(255) DEFAULT NULL,
        `stripe_active` int(11) DEFAULT NULL,
        `stripe_secret_key` varchar(255) DEFAULT NULL,
        `stripe_publishable_key` varchar(255) DEFAULT NULL,
        `currency` varchar(255) DEFAULT 'eur',
        `date_creation` int(11) DEFAULT NULL,
        `date_modification` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:19:"_website_traduction";a:3:{s:5:"count";i:20;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:613:" DROP TABLE IF EXISTS `_website_traduction`;
    CREATE TABLE IF NOT EXISTS `_website_traduction` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `langue` varchar(255) DEFAULT NULL,
        `statut_tinymce` text,
        `title` varchar(255) DEFAULT NULL,
        `slogan` varchar(255) DEFAULT NULL,
        `description` varchar(255) DEFAULT NULL,
        `copyright` varchar(255) DEFAULT NULL,
        `year` varchar(255) DEFAULT NULL,
        `keywords` varchar(255) DEFAULT NULL,
        `date_modification` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:25:"_users_groupes_attributes";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:493:" DROP TABLE IF EXISTS `_users_groupes_attributes`;
    CREATE TABLE IF NOT EXISTS `_users_groupes_attributes` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `active` int(11) DEFAULT '0',
        `required` int(11) DEFAULT '2',
        `groupe_traduction` text,
        `uri` varchar(255) DEFAULT NULL,
        `type` varchar(255) DEFAULT NULL,
        `params` text,
        `date_creation` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:36:"_users_groupes_attributes_traduction";a:3:{s:5:"count";i:0;s:4:"type";s:4:"_mod";s:16:"sql_create_table";s:432:" DROP TABLE IF EXISTS `_users_groupes_attributes_traduction`;
    CREATE TABLE IF NOT EXISTS `_users_groupes_attributes_traduction` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `id_attribute` int(11) DEFAULT NULL,
        `langue` varchar(255) DEFAULT NULL,
        `title` varchar(255) DEFAULT NULL,
        `description` varchar(255) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ; ";}s:7:"_m_news";a:3:{s:5:"count";i:2;s:4:"type";s:4:"news";s:16:"sql_create_table";s:4237:"
        DROP TABLE IF EXISTS `_m_news`;
        CREATE TABLE IF NOT EXISTS _m_news (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `pseudo` varchar(255) DEFAULT NULL,
            `id_user` int(11) DEFAULT '0',
            `id_groupe` int(11) DEFAULT '0',
            `categorie` varchar(255) DEFAULT NULL,
            `active` int(11) NOT NULL DEFAULT '0',
            `author_badge` int(11) NOT NULL DEFAULT '0',
            `comments` int(11) NOT NULL DEFAULT '0',
            `partage` int(11) NOT NULL DEFAULT '1',
            `facebook` int(11) DEFAULT '0',
            `id_facebook` varchar(255) DEFAULT NULL,
            `disqus` int(11) DEFAULT '0',
            `id_disqus` varchar(255) DEFAULT NULL,
            `mailsender` int(11) DEFAULT '0',
            `sendto` varchar(255) DEFAULT NULL,
            `in_rss` int(11) NOT NULL DEFAULT '0',
            `ordre` int(11) NOT NULL DEFAULT '0',
            `groupe_traduction` text,
            `date_creation` int(11) DEFAULT NULL,
            `date_start` int(11) DEFAULT NULL,
            `date_end` int(11) DEFAULT NULL,
            `id_modo` int(111) DEFAULT NULL,
            `val_modo` int(11) DEFAULT '0',
            `date_modo` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ;
          
        DROP TABLE IF EXISTS `_m_news_traduction`;
        CREATE TABLE IF NOT EXISTS _m_news_traduction (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `id_content` int(11) NOT NULL DEFAULT '0',
            `langue` varchar(255) DEFAULT NULL,
            `categorie` varchar(255) DEFAULT NULL,
            `titre` varchar(255) DEFAULT NULL,
            `description` text,
            `article_tinymce` text,
            `uri` varchar(255) DEFAULT NULL,
            `image_gallery` text,
            `meta_titre` varchar(255) DEFAULT NULL,
            `meta_description` varchar(255) DEFAULT NULL,
            `meta_keys` varchar(255) DEFAULT NULL,
            `meta_facebook_type` varchar(255) DEFAULT NULL,
            `meta_facebook_titre` varchar(255) DEFAULT NULL,
            `meta_facebook_description` varchar(255) DEFAULT NULL,
            `meta_facebook_image` varchar(255) DEFAULT NULL,
            `meta_twitter_type` varchar(255) DEFAULT NULL,
            `meta_twitter_titre` varchar(255) DEFAULT NULL,
            `meta_twitter_description` varchar(255) DEFAULT NULL,
            `meta_twitter_image` varchar(255) DEFAULT NULL,
            `meta_twitter_player` varchar(255) DEFAULT NULL,
            `date_modification` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ;
        
        DROP TABLE IF EXISTS `_m_news_version`;
        CREATE TABLE IF NOT EXISTS _m_news_version (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `id_content` int(11) NOT NULL DEFAULT '0',
            `pseudo` varchar(255) DEFAULT NULL,
            `id_user` int(11) DEFAULT '0',
            `id_groupe` int(11) DEFAULT '0',
            `langue` varchar(255) DEFAULT NULL,
            `active` int(11) NOT NULL DEFAULT '0',
            `categorie` varchar(255) DEFAULT NULL,
            `titre` varchar(255) DEFAULT NULL,
            `description` text,
            `article_tinymce` text,
            `uri` varchar(255) DEFAULT NULL,
            `image_gallery` text,
            `meta_titre` varchar(255) DEFAULT NULL,
            `meta_description` varchar(255) DEFAULT NULL,
            `meta_keys` varchar(255) DEFAULT NULL,
            `meta_facebook_type` varchar(255) DEFAULT NULL,
            `meta_facebook_titre` varchar(255) DEFAULT NULL,
            `meta_facebook_description` varchar(255) DEFAULT NULL,
            `meta_facebook_image` varchar(255) DEFAULT NULL,
            `meta_twitter_type` varchar(255) DEFAULT NULL,
            `meta_twitter_titre` varchar(255) DEFAULT NULL,
            `meta_twitter_description` varchar(255) DEFAULT NULL,
            `meta_twitter_image` varchar(255) DEFAULT NULL,
            `meta_twitter_player` varchar(255) DEFAULT NULL,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ;
        
        ";}s:18:"_m_news_traduction";a:3:{s:5:"count";i:40;s:4:"type";s:15:"news_traduction";s:16:"sql_create_table";s:0:"";}s:15:"_m_news_version";a:3:{s:5:"count";i:2;s:4:"type";s:12:"news_version";s:16:"sql_create_table";s:0:"";}s:7:"_m_blog";a:3:{s:5:"count";i:2;s:4:"type";s:4:"blog";s:16:"sql_create_table";s:4322:"
        DROP TABLE IF EXISTS `_m_blog`;
        CREATE TABLE IF NOT EXISTS _m_blog (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `pseudo` varchar(255) DEFAULT NULL,
            `id_user` int(11) DEFAULT '0',
            `id_groupe` int(11) DEFAULT '0',
            `categorie` varchar(255) DEFAULT NULL,
            `active` int(11) NOT NULL DEFAULT '0',
            `author_badge` int(11) NOT NULL DEFAULT '0',
            `comments` int(11) NOT NULL DEFAULT '0',
            `partage` int(11) NOT NULL DEFAULT '1',
            `facebook` int(11) DEFAULT '0',
            `id_facebook` varchar(255) DEFAULT NULL,
            `disqus` int(11) DEFAULT '0',
            `id_disqus` varchar(255) DEFAULT NULL,
            `mailsender` int(11) DEFAULT '0',
            `sendto` varchar(255) DEFAULT NULL,
            `in_rss` int(11) NOT NULL DEFAULT '0',
            `ordre` int(11) NOT NULL DEFAULT '0',
            `groupe_traduction` text,
            `date_creation` int(11) DEFAULT NULL,
            `date_start` int(11) DEFAULT NULL,
            `date_end` int(11) DEFAULT NULL,
            `id_modo` int(111) DEFAULT NULL,
            `val_modo` int(11) DEFAULT '0',
            `date_modo` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ;
          
        DROP TABLE IF EXISTS `_m_blog_traduction`;
        CREATE TABLE IF NOT EXISTS _m_blog_traduction (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `id_content` int(11) NOT NULL DEFAULT '0',
            `langue` varchar(255) DEFAULT NULL,
            `categorie` varchar(255) DEFAULT NULL,
            `image` varchar(255) DEFAULT NULL,
            `titre` varchar(255) DEFAULT NULL,
            `description` text,
            `article_tinymce` text,
            `uri` varchar(255) DEFAULT NULL,
            `image_gallery` text,
            `meta_titre` varchar(255) DEFAULT NULL,
            `meta_description` varchar(255) DEFAULT NULL,
            `meta_keys` varchar(255) DEFAULT NULL,
            `meta_facebook_type` varchar(255) DEFAULT NULL,
            `meta_facebook_titre` varchar(255) DEFAULT NULL,
            `meta_facebook_description` varchar(255) DEFAULT NULL,
            `meta_facebook_image` varchar(255) DEFAULT NULL,
            `meta_twitter_type` varchar(255) DEFAULT NULL,
            `meta_twitter_titre` varchar(255) DEFAULT NULL,
            `meta_twitter_description` varchar(255) DEFAULT NULL,
            `meta_twitter_image` varchar(255) DEFAULT NULL,
            `meta_twitter_player` varchar(255) DEFAULT NULL,
            `date_modification` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ;
        
        DROP TABLE IF EXISTS `_m_blog_version`;
        CREATE TABLE IF NOT EXISTS _m_blog_version (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `id_content` int(11) NOT NULL DEFAULT '0',
            `pseudo` varchar(255) DEFAULT NULL,
            `id_user` int(11) DEFAULT '0',
            `id_groupe` int(11) DEFAULT '0',
            `langue` varchar(255) DEFAULT NULL,
            `active` int(11) NOT NULL DEFAULT '0',
            `categorie` varchar(255) DEFAULT NULL,
            `image` varchar(255) DEFAULT NULL,
            `titre` varchar(255) DEFAULT NULL,
            `description` text,
            `article_tinymce` text,
            `uri` varchar(255) DEFAULT NULL,
            `image_gallery` text,
            `meta_titre` varchar(255) DEFAULT NULL,
            `meta_description` varchar(255) DEFAULT NULL,
            `meta_keys` varchar(255) DEFAULT NULL,
            `meta_facebook_type` varchar(255) DEFAULT NULL,
            `meta_facebook_titre` varchar(255) DEFAULT NULL,
            `meta_facebook_description` varchar(255) DEFAULT NULL,
            `meta_facebook_image` varchar(255) DEFAULT NULL,
            `meta_twitter_type` varchar(255) DEFAULT NULL,
            `meta_twitter_titre` varchar(255) DEFAULT NULL,
            `meta_twitter_description` varchar(255) DEFAULT NULL,
            `meta_twitter_image` varchar(255) DEFAULT NULL,
            `meta_twitter_player` varchar(255) DEFAULT NULL,
            `date_creation` int(11) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ;
        ";}s:18:"_m_blog_traduction";a:3:{s:5:"count";i:40;s:4:"type";s:15:"blog_traduction";s:16:"sql_create_table";s:0:"";}s:15:"_m_blog_version";a:3:{s:5:"count";i:19;s:4:"type";s:12:"blog_version";s:16:"sql_create_table";s:0:"";}}