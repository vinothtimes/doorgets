<?php

class DgBlockTraductionQuery extends AbstractQuery 
{

	protected $_table = '_dg_block_traduction';
    
    protected $_className = 'DgBlockTraduction';

    public function __construct(&$doorGets = null) {
        parent::__construct($doorGets);
    }

	protected $_pk = 'id';

	public function _getPk() {
		return $this->_pk;
	} 

	public function findByPK($Id)
	{
		$this->_findBy['Id'] =  $Id;

		$this->_load();
		return $this;
	} 
		
	public function findById($Id)
	{
		$this->_findBy['Id'] =  $Id;

		$this->_load();
		return $this;
	} 
		
	public function findRangeById($from,$to)
	{
		$this->_findRangeBy['Id'] =  array(
			'from' => $from,
			'to'   => $to
		);

		$this->_load();
		return $this;
	} 


	public function findGreaterThanById($int)
	{
		$this->_findGreaterThanBy['Id'] = $int;

		$this->_load();
		return $this;
	} 


	public function findLessThanById($int)
	{
		$this->_findLessThanBy['Id'] = $int;

		$this->_load();
		return $this;
	} 
		
	public function findByIdBlock($IdBlock)
	{
		$this->_findBy['IdBlock'] =  $IdBlock;

		$this->_load();
		return $this;
	} 
		
	public function findRangeByIdBlock($from,$to)
	{
		$this->_findRangeBy['IdBlock'] =  array(
			'from' => $from,
			'to'   => $to
		);

		$this->_load();
		return $this;
	} 


	public function findGreaterThanByIdBlock($int)
	{
		$this->_findGreaterThanBy['IdBlock'] = $int;

		$this->_load();
		return $this;
	} 


	public function findLessThanByIdBlock($int)
	{
		$this->_findLessThanBy['IdBlock'] = $int;

		$this->_load();
		return $this;
	} 
		
	public function findByUriModule($UriModule)
	{
		$this->_findBy['UriModule'] =  $UriModule;

		$this->_load();
		return $this;
	} 
		
	public function findByLangue($Langue)
	{
		$this->_findBy['Langue'] =  $Langue;

		$this->_load();
		return $this;
	} 
		
	public function findByTitre($Titre)
	{
		$this->_findBy['Titre'] =  $Titre;

		$this->_load();
		return $this;
	} 
		
	public function findByDescription($Description)
	{
		$this->_findBy['Description'] =  $Description;

		$this->_load();
		return $this;
	} 
		
	public function findByArticleTinymce($ArticleTinymce)
	{
		$this->_findBy['ArticleTinymce'] =  $ArticleTinymce;

		$this->_load();
		return $this;
	} 
		
	public function findByDateModification($DateModification)
	{
		$this->_findBy['DateModification'] =  $DateModification;

		$this->_load();
		return $this;
	} 
		
	public function findRangeByDateModification($from,$to)
	{
		$this->_findRangeBy['DateModification'] =  array(
			'from' => $from,
			'to'   => $to
		);

		$this->_load();
		return $this;
	} 


	public function findGreaterThanByDateModification($int)
	{
		$this->_findGreaterThanBy['DateModification'] = $int;

		$this->_load();
		return $this;
	} 


	public function findLessThanByDateModification($int)
	{
		$this->_findLessThanBy['DateModification'] = $int;

		$this->_load();
		return $this;
	} 

		
	public function findOneById($Id)
	{
		$this->_findOneBy['Id'] =  $Id;

		$this->_load();
		return $this->_result;
	} 
		
	public function findOneByIdBlock($IdBlock)
	{
		$this->_findOneBy['IdBlock'] =  $IdBlock;

		$this->_load();
		return $this->_result;
	} 
		
	public function findOneByUriModule($UriModule)
	{
		$this->_findOneBy['UriModule'] =  $UriModule;

		$this->_load();
		return $this->_result;
	} 
		
	public function findOneByLangue($Langue)
	{
		$this->_findOneBy['Langue'] =  $Langue;

		$this->_load();
		return $this->_result;
	} 
		
	public function findOneByTitre($Titre)
	{
		$this->_findOneBy['Titre'] =  $Titre;

		$this->_load();
		return $this->_result;
	} 
		
	public function findOneByDescription($Description)
	{
		$this->_findOneBy['Description'] =  $Description;

		$this->_load();
		return $this->_result;
	} 
		
	public function findOneByArticleTinymce($ArticleTinymce)
	{
		$this->_findOneBy['ArticleTinymce'] =  $ArticleTinymce;

		$this->_load();
		return $this->_result;
	} 
		
	public function findOneByDateModification($DateModification)
	{
		$this->_findOneBy['DateModification'] =  $DateModification;

		$this->_load();
		return $this->_result;
	} 

		
	public function findByLikeId($Id)
	{
		$this->_findByLike['Id'] =  $Id;

		$this->_load();
		return $this;
	} 
		
	public function findByLikeIdBlock($IdBlock)
	{
		$this->_findByLike['IdBlock'] =  $IdBlock;

		$this->_load();
		return $this;
	} 
		
	public function findByLikeUriModule($UriModule)
	{
		$this->_findByLike['UriModule'] =  $UriModule;

		$this->_load();
		return $this;
	} 
		
	public function findByLikeLangue($Langue)
	{
		$this->_findByLike['Langue'] =  $Langue;

		$this->_load();
		return $this;
	} 
		
	public function findByLikeTitre($Titre)
	{
		$this->_findByLike['Titre'] =  $Titre;

		$this->_load();
		return $this;
	} 
		
	public function findByLikeDescription($Description)
	{
		$this->_findByLike['Description'] =  $Description;

		$this->_load();
		return $this;
	} 
		
	public function findByLikeArticleTinymce($ArticleTinymce)
	{
		$this->_findByLike['ArticleTinymce'] =  $ArticleTinymce;

		$this->_load();
		return $this;
	} 
		
	public function findByLikeDateModification($DateModification)
	{
		$this->_findByLike['DateModification'] =  $DateModification;

		$this->_load();
		return $this;
	} 

		
	public function filterById($Id, $condition = 'AND')
	{
		
		$_condition = $this->isAndOr($condition);
		$this->loadFilterBy('Id',$Id,$_condition);

		$this->_load();
		return $this;
	} 
		
	public function filterRangeById($from,$to)
	{
		$this->_filterRangeBy['Id'] =  array(
			'from' => $from,
			'to'   => $to
		);

		$this->_load();
		return $this;
	} 


	public function filterGreaterThanById($int)
	{
		$this->_filterGreaterThanBy['Id'] = $int;

		$this->_load();
		return $this;
	} 


	public function filterLessThanById($int)
	{
		$this->_filterLessThanBy['Id'] = $int;

		$this->_load();
		return $this;
	} 
		
	public function filterByIdBlock($IdBlock, $condition = 'AND')
	{
		
		$_condition = $this->isAndOr($condition);
		$this->loadFilterBy('IdBlock',$IdBlock,$_condition);

		$this->_load();
		return $this;
	} 
		
	public function filterRangeByIdBlock($from,$to)
	{
		$this->_filterRangeBy['IdBlock'] =  array(
			'from' => $from,
			'to'   => $to
		);

		$this->_load();
		return $this;
	} 


	public function filterGreaterThanByIdBlock($int)
	{
		$this->_filterGreaterThanBy['IdBlock'] = $int;

		$this->_load();
		return $this;
	} 


	public function filterLessThanByIdBlock($int)
	{
		$this->_filterLessThanBy['IdBlock'] = $int;

		$this->_load();
		return $this;
	} 
		
	public function filterByUriModule($UriModule, $condition = 'AND')
	{
		
		$_condition = $this->isAndOr($condition);
		$this->loadFilterBy('UriModule',$UriModule,$_condition);

		$this->_load();
		return $this;
	} 
		
	public function filterByLangue($Langue, $condition = 'AND')
	{
		
		$_condition = $this->isAndOr($condition);
		$this->loadFilterBy('Langue',$Langue,$_condition);

		$this->_load();
		return $this;
	} 
		
	public function filterByTitre($Titre, $condition = 'AND')
	{
		
		$_condition = $this->isAndOr($condition);
		$this->loadFilterBy('Titre',$Titre,$_condition);

		$this->_load();
		return $this;
	} 
		
	public function filterByDescription($Description, $condition = 'AND')
	{
		
		$_condition = $this->isAndOr($condition);
		$this->loadFilterBy('Description',$Description,$_condition);

		$this->_load();
		return $this;
	} 
		
	public function filterByArticleTinymce($ArticleTinymce, $condition = 'AND')
	{
		
		$_condition = $this->isAndOr($condition);
		$this->loadFilterBy('ArticleTinymce',$ArticleTinymce,$_condition);

		$this->_load();
		return $this;
	} 
		
	public function filterByDateModification($DateModification, $condition = 'AND')
	{
		
		$_condition = $this->isAndOr($condition);
		$this->loadFilterBy('DateModification',$DateModification,$_condition);

		$this->_load();
		return $this;
	} 
		
	public function filterRangeByDateModification($from,$to)
	{
		$this->_filterRangeBy['DateModification'] =  array(
			'from' => $from,
			'to'   => $to
		);

		$this->_load();
		return $this;
	} 


	public function filterGreaterThanByDateModification($int)
	{
		$this->_filterGreaterThanBy['DateModification'] = $int;

		$this->_load();
		return $this;
	} 


	public function filterLessThanByDateModification($int)
	{
		$this->_filterLessThanBy['DateModification'] = $int;

		$this->_load();
		return $this;
	} 

		
	public function filterLikeById($Id)
	{
		$this->_filterLikeBy['Id'] =  $Id;

		$this->_load();
		return $this;
	} 
		
	public function filterLikeByIdBlock($IdBlock)
	{
		$this->_filterLikeBy['IdBlock'] =  $IdBlock;

		$this->_load();
		return $this;
	} 
		
	public function filterLikeByUriModule($UriModule)
	{
		$this->_filterLikeBy['UriModule'] =  $UriModule;

		$this->_load();
		return $this;
	} 
		
	public function filterLikeByLangue($Langue)
	{
		$this->_filterLikeBy['Langue'] =  $Langue;

		$this->_load();
		return $this;
	} 
		
	public function filterLikeByTitre($Titre)
	{
		$this->_filterLikeBy['Titre'] =  $Titre;

		$this->_load();
		return $this;
	} 
		
	public function filterLikeByDescription($Description)
	{
		$this->_filterLikeBy['Description'] =  $Description;

		$this->_load();
		return $this;
	} 
		
	public function filterLikeByArticleTinymce($ArticleTinymce)
	{
		$this->_filterLikeBy['ArticleTinymce'] =  $ArticleTinymce;

		$this->_load();
		return $this;
	} 
		
	public function filterLikeByDateModification($DateModification)
	{
		$this->_filterLikeBy['DateModification'] =  $DateModification;

		$this->_load();
		return $this;
	} 

		
	public function orderById($direction = 'ASC')
	{
		$this->loadDirection('id',$direction);
		
		return $this;
	} 
		
	public function orderByIdBlock($direction = 'ASC')
	{
		$this->loadDirection('id_block',$direction);
		
		return $this;
	} 
		
	public function orderByUriModule($direction = 'ASC')
	{
		$this->loadDirection('uri_module',$direction);
		
		return $this;
	} 
		
	public function orderByLangue($direction = 'ASC')
	{
		$this->loadDirection('langue',$direction);
		
		return $this;
	} 
		
	public function orderByTitre($direction = 'ASC')
	{
		$this->loadDirection('titre',$direction);
		
		return $this;
	} 
		
	public function orderByDescription($direction = 'ASC')
	{
		$this->loadDirection('description',$direction);
		
		return $this;
	} 
		
	public function orderByArticleTinymce($direction = 'ASC')
	{
		$this->loadDirection('article_tinymce',$direction);
		
		return $this;
	} 
		
	public function orderByDateModification($direction = 'ASC')
	{
		$this->loadDirection('date_modification',$direction);
		
		return $this;
	} 

	

	public function _getMap() { 

		
		$parentMap = parent::_getMap();

		return array_merge($parentMap, array(            
		    'Id' =>  'id',            
		    'IdBlock' =>  'id_block',            
		    'UriModule' =>  'uri_module',            
		    'Langue' =>  'langue',            
		    'Titre' =>  'titre',            
		    'Description' =>  'description',            
		    'ArticleTinymce' =>  'article_tinymce',            
		    'DateModification' =>  'date_modification',		
		)); 

	} 


}