<?php

class UsersTrackEntity extends AbstractEntity
{

	

	/**
	* @type  : int
	* @size  : 11 
	* @key   : PRIMARY KEY 
	* @extra : AUTO INCREMENT
	*/
	protected $Id; 
	

	/**
	* @type  : varchar
	* @size  : 255  
	*/
	protected $IdSession; 
	

	/**
	* @type  : int
	* @size  : 11  
	*/
	protected $IdUser; 
	

	/**
	* @type  : int
	* @size  : 11  
	*/
	protected $IdGroupe; 
	

	/**
	* @type  : varchar
	* @size  : 255  
	*/
	protected $Langue; 
	

	/**
	* @type  : varchar
	* @size  : 255  
	*/
	protected $Title; 
	

	/**
	* @type  : varchar
	* @size  : 255  
	*/
	protected $UriModule; 
	

	/**
	* @type  : text
	* @size  : 0  
	*/
	protected $IdContent; 
	

	/**
	* @type  : varchar
	* @size  : 255  
	*/
	protected $Action; 
	

	/**
	* @type  : varchar
	* @size  : 255  
	*/
	protected $IpUser; 
	

	/**
	* @type  : varchar
	* @size  : 255  
	*/
	protected $UrlPage; 
	

	/**
	* @type  : varchar
	* @size  : 255  
	*/
	protected $UrlReferer; 
	

	/**
	* @type  : int
	* @size  : 11  
	*/
	protected $Date; 
 
	

	public function setId($Id)
	{
		
		$this->Id = $Id;

		return $this;
	} 
	

	public function setIdSession($IdSession)
	{
		
		$this->IdSession = $IdSession;

		return $this;
	} 
	

	public function setIdUser($IdUser)
	{
		
		$this->IdUser = $IdUser;

		return $this;
	} 
	

	public function setIdGroupe($IdGroupe)
	{
		
		$this->IdGroupe = $IdGroupe;

		return $this;
	} 
	

	public function setLangue($Langue)
	{
		
		$this->Langue = $Langue;

		return $this;
	} 
	

	public function setTitle($Title)
	{
		
		$this->Title = $Title;

		return $this;
	} 
	

	public function setUriModule($UriModule)
	{
		
		$this->UriModule = $UriModule;

		return $this;
	} 
	

	public function setIdContent($IdContent)
	{
		
		$this->IdContent = $IdContent;

		return $this;
	} 
	

	public function setAction($Action)
	{
		
		$this->Action = $Action;

		return $this;
	} 
	

	public function setIpUser($IpUser)
	{
		
		$this->IpUser = $IpUser;

		return $this;
	} 
	

	public function setUrlPage($UrlPage)
	{
		
		$this->UrlPage = $UrlPage;

		return $this;
	} 
	

	public function setUrlReferer($UrlReferer)
	{
		
		$this->UrlReferer = $UrlReferer;

		return $this;
	} 
	

	public function setDate($Date)
	{
		
		$this->Date = $Date;

		return $this;
	} 

		
	public function getId()
	{
		return $this->Id ;
	} 
		
	public function getIdSession()
	{
		return $this->IdSession ;
	} 
		
	public function getIdUser()
	{
		return $this->IdUser ;
	} 
		
	public function getIdGroupe()
	{
		return $this->IdGroupe ;
	} 
		
	public function getLangue()
	{
		return $this->Langue ;
	} 
		
	public function getTitle()
	{
		return $this->Title ;
	} 
		
	public function getUriModule()
	{
		return $this->UriModule ;
	} 
		
	public function getIdContent()
	{
		return $this->IdContent ;
	} 
		
	public function getAction()
	{
		return $this->Action ;
	} 
		
	public function getIpUser()
	{
		return $this->IpUser ;
	} 
		
	public function getUrlPage()
	{
		return $this->UrlPage ;
	} 
		
	public function getUrlReferer()
	{
		return $this->UrlReferer ;
	} 
		
	public function getDate()
	{
		return $this->Date ;
	} 

		
	public function getValidationId()
	{
		return array(
			'type'	         => 'int', 
			'size'			 => 11, 
			'unique' 		 => false,
			'required' 		 => false,
			'primary_key' 	 => true,
			'auto_increment' => true
		);
	} 
		
	public function getValidationIdSession()
	{
		return array(
			'type'	         => 'varchar', 
			'size'			 => 255, 
			'unique' 		 => false,
			'required' 		 => false,
			'primary_key' 	 => false,
			'auto_increment' => false
		);
	} 
		
	public function getValidationIdUser()
	{
		return array(
			'type'	         => 'int', 
			'size'			 => 11, 
			'unique' 		 => false,
			'required' 		 => false,
			'primary_key' 	 => false,
			'auto_increment' => false
		);
	} 
		
	public function getValidationIdGroupe()
	{
		return array(
			'type'	         => 'int', 
			'size'			 => 11, 
			'unique' 		 => false,
			'required' 		 => false,
			'primary_key' 	 => false,
			'auto_increment' => false
		);
	} 
		
	public function getValidationLangue()
	{
		return array(
			'type'	         => 'varchar', 
			'size'			 => 255, 
			'unique' 		 => false,
			'required' 		 => false,
			'primary_key' 	 => false,
			'auto_increment' => false
		);
	} 
		
	public function getValidationTitle()
	{
		return array(
			'type'	         => 'varchar', 
			'size'			 => 255, 
			'unique' 		 => false,
			'required' 		 => false,
			'primary_key' 	 => false,
			'auto_increment' => false
		);
	} 
		
	public function getValidationUriModule()
	{
		return array(
			'type'	         => 'varchar', 
			'size'			 => 255, 
			'unique' 		 => false,
			'required' 		 => false,
			'primary_key' 	 => false,
			'auto_increment' => false
		);
	} 
		
	public function getValidationIdContent()
	{
		return array(
			'type'	         => 'text', 
			'size'			 => 0, 
			'unique' 		 => false,
			'required' 		 => false,
			'primary_key' 	 => false,
			'auto_increment' => false
		);
	} 
		
	public function getValidationAction()
	{
		return array(
			'type'	         => 'varchar', 
			'size'			 => 255, 
			'unique' 		 => false,
			'required' 		 => false,
			'primary_key' 	 => false,
			'auto_increment' => false
		);
	} 
		
	public function getValidationIpUser()
	{
		return array(
			'type'	         => 'varchar', 
			'size'			 => 255, 
			'unique' 		 => false,
			'required' 		 => false,
			'primary_key' 	 => false,
			'auto_increment' => false
		);
	} 
		
	public function getValidationUrlPage()
	{
		return array(
			'type'	         => 'varchar', 
			'size'			 => 255, 
			'unique' 		 => false,
			'required' 		 => false,
			'primary_key' 	 => false,
			'auto_increment' => false
		);
	} 
		
	public function getValidationUrlReferer()
	{
		return array(
			'type'	         => 'varchar', 
			'size'			 => 255, 
			'unique' 		 => false,
			'required' 		 => false,
			'primary_key' 	 => false,
			'auto_increment' => false
		);
	} 
		
	public function getValidationDate()
	{
		return array(
			'type'	         => 'int', 
			'size'			 => 11, 
			'unique' 		 => false,
			'required' 		 => false,
			'primary_key' 	 => false,
			'auto_increment' => false
		);
	} 

	

	public function _getMap() { 

		
		$parentMap = parent::_getMap();

		return array_merge($parentMap, array(            
		    'Id' =>  'id',            
		    'IdSession' =>  'id_session',            
		    'IdUser' =>  'id_user',            
		    'IdGroupe' =>  'id_groupe',            
		    'Langue' =>  'langue',            
		    'Title' =>  'title',            
		    'UriModule' =>  'uri_module',            
		    'IdContent' =>  'id_content',            
		    'Action' =>  'action',            
		    'IpUser' =>  'ip_user',            
		    'UrlPage' =>  'url_page',            
		    'UrlReferer' =>  'url_referer',            
		    'Date' =>  'date',		
		)); 

	} 


    public function __construct($data = array(),&$doorGets = null, $joinMaps = array()) {
        parent::__construct($data,$doorGets,$joinMaps);
    }
}