<?php

class DgFirewallQuery extends AbstractQuery 
{

	protected $_table = '_dg_firewall';
    
    protected $_className = 'DgFirewall';

    public function __construct(&$doorGets = null) {
        parent::__construct($doorGets);
    }

	protected $_pk = 'id';

	public function _getPk() {
		return $this->_pk;
	} 

	public function findByPK($Id)
	{
		$this->_findBy['Id'] =  $Id;

		$this->_load();
		return $this;
	} 
		
	public function findById($Id)
	{
		$this->_findBy['Id'] =  $Id;

		$this->_load();
		return $this;
	} 
		
	public function findRangeById($from,$to)
	{
		$this->_findRangeBy['Id'] =  array(
			'from' => $from,
			'to'   => $to
		);

		$this->_load();
		return $this;
	} 


	public function findGreaterThanById($int)
	{
		$this->_findGreaterThanBy['Id'] = $int;

		$this->_load();
		return $this;
	} 


	public function findLessThanById($int)
	{
		$this->_findLessThanBy['Id'] = $int;

		$this->_load();
		return $this;
	} 
		
	public function findByAdresseIp($AdresseIp)
	{
		$this->_findBy['AdresseIp'] =  $AdresseIp;

		$this->_load();
		return $this;
	} 
		
	public function findByLevel($Level)
	{
		$this->_findBy['Level'] =  $Level;

		$this->_load();
		return $this;
	} 
		
	public function findRangeByLevel($from,$to)
	{
		$this->_findRangeBy['Level'] =  array(
			'from' => $from,
			'to'   => $to
		);

		$this->_load();
		return $this;
	} 


	public function findGreaterThanByLevel($int)
	{
		$this->_findGreaterThanBy['Level'] = $int;

		$this->_load();
		return $this;
	} 


	public function findLessThanByLevel($int)
	{
		$this->_findLessThanBy['Level'] = $int;

		$this->_load();
		return $this;
	} 
		
	public function findByDateCreation($DateCreation)
	{
		$this->_findBy['DateCreation'] =  $DateCreation;

		$this->_load();
		return $this;
	} 
		
	public function findRangeByDateCreation($from,$to)
	{
		$this->_findRangeBy['DateCreation'] =  array(
			'from' => $from,
			'to'   => $to
		);

		$this->_load();
		return $this;
	} 


	public function findGreaterThanByDateCreation($int)
	{
		$this->_findGreaterThanBy['DateCreation'] = $int;

		$this->_load();
		return $this;
	} 


	public function findLessThanByDateCreation($int)
	{
		$this->_findLessThanBy['DateCreation'] = $int;

		$this->_load();
		return $this;
	} 

		
	public function findOneById($Id)
	{
		$this->_findOneBy['Id'] =  $Id;

		$this->_load();
		return $this->_result;
	} 
		
	public function findOneByAdresseIp($AdresseIp)
	{
		$this->_findOneBy['AdresseIp'] =  $AdresseIp;

		$this->_load();
		return $this->_result;
	} 
		
	public function findOneByLevel($Level)
	{
		$this->_findOneBy['Level'] =  $Level;

		$this->_load();
		return $this->_result;
	} 
		
	public function findOneByDateCreation($DateCreation)
	{
		$this->_findOneBy['DateCreation'] =  $DateCreation;

		$this->_load();
		return $this->_result;
	} 

		
	public function findByLikeId($Id)
	{
		$this->_findByLike['Id'] =  $Id;

		$this->_load();
		return $this;
	} 
		
	public function findByLikeAdresseIp($AdresseIp)
	{
		$this->_findByLike['AdresseIp'] =  $AdresseIp;

		$this->_load();
		return $this;
	} 
		
	public function findByLikeLevel($Level)
	{
		$this->_findByLike['Level'] =  $Level;

		$this->_load();
		return $this;
	} 
		
	public function findByLikeDateCreation($DateCreation)
	{
		$this->_findByLike['DateCreation'] =  $DateCreation;

		$this->_load();
		return $this;
	} 

		
	public function filterById($Id, $condition = 'AND')
	{
		
		$_condition = $this->isAndOr($condition);
		$this->loadFilterBy('Id',$Id,$_condition);

		$this->_load();
		return $this;
	} 
		
	public function filterRangeById($from,$to)
	{
		$this->_filterRangeBy['Id'] =  array(
			'from' => $from,
			'to'   => $to
		);

		$this->_load();
		return $this;
	} 


	public function filterGreaterThanById($int)
	{
		$this->_filterGreaterThanBy['Id'] = $int;

		$this->_load();
		return $this;
	} 


	public function filterLessThanById($int)
	{
		$this->_filterLessThanBy['Id'] = $int;

		$this->_load();
		return $this;
	} 
		
	public function filterByAdresseIp($AdresseIp, $condition = 'AND')
	{
		
		$_condition = $this->isAndOr($condition);
		$this->loadFilterBy('AdresseIp',$AdresseIp,$_condition);

		$this->_load();
		return $this;
	} 
		
	public function filterByLevel($Level, $condition = 'AND')
	{
		
		$_condition = $this->isAndOr($condition);
		$this->loadFilterBy('Level',$Level,$_condition);

		$this->_load();
		return $this;
	} 
		
	public function filterRangeByLevel($from,$to)
	{
		$this->_filterRangeBy['Level'] =  array(
			'from' => $from,
			'to'   => $to
		);

		$this->_load();
		return $this;
	} 


	public function filterGreaterThanByLevel($int)
	{
		$this->_filterGreaterThanBy['Level'] = $int;

		$this->_load();
		return $this;
	} 


	public function filterLessThanByLevel($int)
	{
		$this->_filterLessThanBy['Level'] = $int;

		$this->_load();
		return $this;
	} 
		
	public function filterByDateCreation($DateCreation, $condition = 'AND')
	{
		
		$_condition = $this->isAndOr($condition);
		$this->loadFilterBy('DateCreation',$DateCreation,$_condition);

		$this->_load();
		return $this;
	} 
		
	public function filterRangeByDateCreation($from,$to)
	{
		$this->_filterRangeBy['DateCreation'] =  array(
			'from' => $from,
			'to'   => $to
		);

		$this->_load();
		return $this;
	} 


	public function filterGreaterThanByDateCreation($int)
	{
		$this->_filterGreaterThanBy['DateCreation'] = $int;

		$this->_load();
		return $this;
	} 


	public function filterLessThanByDateCreation($int)
	{
		$this->_filterLessThanBy['DateCreation'] = $int;

		$this->_load();
		return $this;
	} 

		
	public function filterLikeById($Id)
	{
		$this->_filterLikeBy['Id'] =  $Id;

		$this->_load();
		return $this;
	} 
		
	public function filterLikeByAdresseIp($AdresseIp)
	{
		$this->_filterLikeBy['AdresseIp'] =  $AdresseIp;

		$this->_load();
		return $this;
	} 
		
	public function filterLikeByLevel($Level)
	{
		$this->_filterLikeBy['Level'] =  $Level;

		$this->_load();
		return $this;
	} 
		
	public function filterLikeByDateCreation($DateCreation)
	{
		$this->_filterLikeBy['DateCreation'] =  $DateCreation;

		$this->_load();
		return $this;
	} 

		
	public function orderById($direction = 'ASC')
	{
		$this->loadDirection('id',$direction);
		
		return $this;
	} 
		
	public function orderByAdresseIp($direction = 'ASC')
	{
		$this->loadDirection('adresse_ip',$direction);
		
		return $this;
	} 
		
	public function orderByLevel($direction = 'ASC')
	{
		$this->loadDirection('level',$direction);
		
		return $this;
	} 
		
	public function orderByDateCreation($direction = 'ASC')
	{
		$this->loadDirection('date_creation',$direction);
		
		return $this;
	} 

	

	public function _getMap() { 

		
		$parentMap = parent::_getMap();

		return array_merge($parentMap, array(            
		    'Id' =>  'id',            
		    'AdresseIp' =>  'adresse_ip',            
		    'Level' =>  'level',            
		    'DateCreation' =>  'date_creation',		
		)); 

	} 


}