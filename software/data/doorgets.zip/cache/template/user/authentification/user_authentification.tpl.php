<?php 

/*******************************************************************************
/*******************************************************************************
    doorGets 7.0 - 20, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2013 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/t/en/?contact
    
/*******************************************************************************
    -= One life for One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

?>
<div class="text-center">
    <a href="<?php echo BASE; ?>" class="logo-auth" title="<?php echo $this->doorGets->__('Accéder au site'); ?>"><img src="<?php echo BASE; ?>skin/img/logo_auth.png"></a>
</div>
<div class="doorGets-box-login">
    <?php if(count($this->doorGets->allLanguagesWebsite) > 1): ?>
    <div  class="btn-group pull-right btn-langue-change">
        <a  class="btn btn-default dropdown-toggle" data-toggle="dropdown" href="#">
            <?php echo $this->doorGets->allLanguagesWebsite[$this->doorGets->myLanguage]; ?> 
            <b class="caret"></b>
        </a>
        <ul class="dropdown-menu" role="menu">
            <?php foreach($this->doorGets->allLanguagesWebsite as $key=>$label): ?>
                <li <?php if($this->doorGets->myLanguage === $key): ?>class="active"<?php endif; ?> >
                    <a class="navbut" href="<?php echo URL_USER.$key.'/?controller=authentification' ?>">
                        <?php echo $label; ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>
    <h3 class="doorGets-title">
        <?php echo $this->doorGets->__('Identifiez-vous'); ?>
    </h3>
    <?php if($fireWallIp['level'] < 6): ?>
        <div>
            <?php if($fireWallIp['level'] > 1): ?>
            <div class="alert alert-danger" role="alert">
                <b class="glyphicon glyphicon-warning-sign"></b>
                <?php echo $this->doorGets->__("Nombre de tentatives restantes"); ?> <span class="badge"><?php echo ( 6 - $fireWallIp['level']); ?></span>
            </div>
            <?php endif; ?>
            <?php echo $this->doorGets->Form->open('post','',''); ?>

            <?php if($this->doorGets->configWeb['oauth_google_active']): ?>
            <a href="<?php echo BASE; ?>/oauth2/google/login/" class="google-sigin">Se connecter avec Google</a> 
            <div class="separateur-tb"></div>
            <?php endif; ?>

            <?php if($this->doorGets->configWeb['oauth_facebook_active']): ?>
            <a href="<?php echo BASE; ?>/oauth2/facebook/login/" class="facebook-sigin">Se connecter avec Facebook</a> 
            <div class="separateur-tb"></div>
            <?php endif; ?>

            <?php echo $this->doorGets->Form->input('<b class="glyphicon glyphicon-user"></b> '.$this->doorGets->__('Adresse électronique'),'login'); ?>
            <br />
            <?php echo '<small class="right"><a href="?controller=authentification&action=forget">'.$this->doorGets->__('Mot de passe oublié').' ?</a></small>'.$this->doorGets->Form->input('<b class="glyphicon glyphicon-lock"></b> '.$this->doorGets->__('Mot de passe'),'password','password'); ?>
            
            <div class="text-center">
                <?php echo $this->doorGets->Form->submit($this->doorGets->__('Se connecter'),'','btn btn-lg btn-info'); ?>
            </div>
            <?php echo $this->doorGets->Form->close(); ?>
        </div>
    <?php else: ?>
        <div class="alert alert-danger text-center" role="alert">
            <b class="glyphicon glyphicon-warning-sign"></b>
            <?php echo $this->doorGets->__('Suite à de nombreuses tentatives de connexion sans succès vous devez patienter'); ?> 
            <b><?php echo $fireWallIp['time_stop']; ?></b>
            <?php if($fireWallIp['time_stop'] > 1 ): ?> <?php echo $this->doorGets->__('minutes'); ?> <?php else: ?> <?php echo $this->doorGets->__('minutes'); ?> <?php endif; ?> !
        </div>
        <div class="alert alert-info text-center" role="alert">
            <?php echo $this->doorGets->__('Adresse IP'); ?> : <?php echo $fireWallIp['adresse_ip']; ?>
        </div>
    <?php endif; ?>

</div>
<div class="text-center ">
    <?php if($countGroupes > 0): ?>
    <br />
        <?php if($countGroupes === 1): ?>
            <a href="?controller=authentification&action=register" class="btn btn-lg btn-link"><b class="glyphicon glyphicon-star"></b> <?php echo $this->doorGets->__("S'inscrire"); ?></a>
        <?php else: ?>
            <?php foreach($groupes as $id => $groupe): ?>
                <a href="?controller=authentification&action=register&groupe=<?php echo $groupe['uri']; ?>" class="btn btn-lg btn-link"><b class="glyphicon glyphicon-star"></b> <?php echo $this->doorGets->__("S'inscrire en tant que"); ?> <?php echo $groupe['title']; ?></a>
                <br />
            <?php endforeach; ?>
        <?php endif;  endif; ?>
    <a href="<?php echo URL;  if(count($this->doorGets->allLanguagesWebsite > 1)):  echo 't/'.$this->doorGets->myLanguage.'/';  endif; ?>" class="btn btn-lg btn-link"><b class="glyphicon glyphicon-home"></b> <?php echo $this->doorGets->__('Accéder au site'); ?></a>
</div>
