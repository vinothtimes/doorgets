<?php 

/*******************************************************************************
/*******************************************************************************
    doorGets 7.0 - 20, February 2014
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2015 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/t/en/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/



?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title">
        
    </div>
    <div class="doorGets-rubrique-center-content">
        <legend>
            <?php if($canAddUser): ?>
                <span class="create" ><a href="?controller=users&action=add"class="violet" ><b class="glyphicon glyphicon-plus"></b> <?php echo $this->doorGets->__('Créer un utilisateur'); ?></a></span>
            <?php endif; ?>
            <b class="glyphicon glyphicon-user"></b> <?php echo $this->doorGets->__('Utilisateurs'); ?> 
        </legend>
        <div style="width: 100%;padding: 10px 0 0;overflow: hidden;">
            <?php if($canAddUser): ?>
            <div style="overflow: hidden;">
                <div style="float: left;padding: 7px 0 ">
                    <i>
                        <?php if(!empty($cAll)): ?> <?php echo ($ini+1); ?> <?php echo $this->doorGets->__("à"); ?> <?php echo $finalPer; ?> <?php echo $this->doorGets->__("sur"); ?> <?php endif; ?>
                        <b><?php echo $cResultsInt.' '; ?> <?php if( $cResultsInt > 1 ):  echo $this->doorGets->__('Utilisateurs'); ?> <?php else: ?> <?php echo $this->doorGets->__('Utilisateur'); ?> <?php endif; ?></b>
                        <?php if(!empty($q)): ?> <?php echo $this->doorGets->__('pour la recherche : ').' <b>'.$q.'</b>'; ?> <?php endif; ?>
                    </i>
                    <span id="doorGets-sort-count">
                        <?php echo $this->doorGets->__('Par'); ?>
                        <a href="<?php echo $urlPagePosition; ?>&gby=10" <?php if($per=='10'): ?> class="active" <?php endif; ?>>10</a>
                        <a href="<?php echo $urlPagePosition; ?>&gby=20" <?php if($per=='20'): ?> class="active" <?php endif; ?>>20</a>
                        <a href="<?php echo $urlPagePosition; ?>&gby=50" <?php if($per=='50'): ?> class="active" <?php endif; ?>>50</a>
                        <a href="<?php echo $urlPagePosition; ?>&gby=100" <?php if($per=='100'): ?> class="active" <?php endif; ?>>100</a>
                    </span>
                     
                </div>
                <div  class="doorGets-box-search-module">
                    <?php echo $this->doorGets->Form['_search_filter']->open('post',$urlPageGo,''); ?>
                    <?php echo $this->doorGets->Form['_search_filter']->submit($this->doorGets->__('Chercher'),'','btn btn-success'); ?>
                    <a href="?controller=<?php echo $this->doorGets->controllerNameNow(); ?>&lg=<?php echo $lgActuel; ?>" class="btn btn-danger doorGets-filter-bt" ><?php echo $this->doorGets->__('Reset'); ?></a>
                </div>
            </div>
            <div class="separateur-tb"></div>
            
                <?php echo $block->getHtml();  echo $this->doorGets->Form['_search']->close();  if(!empty($cAll)): ?>
                    

                    <?php echo $formMassDelete; ?>
                    <br />
                    <?php echo $valPage; ?>
                    <br /><br />
                    
                <?php else: ?>
                   
                    <?php if(!empty($aGroupeFilter)): ?>
                        <div class="alert alert-info">
                            <?php echo $this->doorGets->__("Aucun utilisateur trouvé pour votre recherche."); ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <?php echo $this->doorGets->__("Il n'y a actuellement aucun utilisateur"); ?>
                        </div>
                    <?php endif;  endif; ?> 
            <?php else: ?>
                <div class="alert alert-info">
                    <?php echo $this->doorGets->__("Il n'y a actuellement aucun utilisateur"); ?>
                </div>
            <?php endif; ?>
        </div>
        
    </div>
</div>
