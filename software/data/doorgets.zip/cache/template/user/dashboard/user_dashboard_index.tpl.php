<?php 

/*******************************************************************************
/*******************************************************************************
    doorGets 7.0 - 31, August 2015
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2015 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/t/en/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title page-header">

    </div>
    <div class="doorGets-rubrique-center-content">
        <legend>
            <b class="glyphicon glyphicon-dashboard"></b> <?php echo $this->doorGets->__('Tableau de bord'); ?>
        </legend>
        <div class="row">
            <div class="col-md-8">
                <div class="panel panel-default box-dash">
                    <div class="box-dash-title panel-heading">
                        <b class="glyphicon glyphicon-signal"></b> <?php echo $this->doorGets->__('Activité'); ?>
                    </div>
                    <div class="panel-body box-dash-content">
                        <?php if(!empty($history)): ?>
                            <?php foreach($history as $track): ?>
                                <?php if(array_key_exists('history',$track)): ?>
                                <div class="media">
                                    <div class="media-left media-middle">
                                        <img class="media-object avatars" src="<?php echo URL.'data/users/'.$track['user_infos']['avatar']; ?>" >    
                                    </div>
                                    <div class="media-body">
                                        <h4><small><?php echo $track['date']; ?></small></h4>
                                        <small class="pull-right"></small>
                                        <?php echo $track['history']; ?>
                                    </div>
                                </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="comment-center"><?php echo $this->doorGets->__("Il n'y a pas encore d'historique"); ?>.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="row">
                    <?php if($is_comment_modo): ?>
                        <div class="col-md-12">
                            <div class="panel panel-default box-dash">
                                <div class="box-dash-title panel-heading">
                                    <a href="?controller=comment">
                                        <b class="glyphicon glyphicon-comment"></b>  <?php echo $this->doorGets->__("Commentaire"); ?>
                                    </a>
                                </div>
                                <div class="panel-body box-dash-content">
                                    <?php if(!empty($lastComments)): ?>
                                        <ul class="list-group">  
                                        <?php foreach($lastComments as $v): ?>
                                            <?php 
                                                $imgVal = '<img src="'.BASE_IMG.'puce-rouge.png" title="'.$this->doorGets->__('Bloquer').'" />';
                                                if ($v['validation'] === '2') {
                                                    $imgVal = '<img src="'.BASE_IMG.'puce-verte.png" title="'.$this->doorGets->__('Activer').'" />';
                                                }
                                                if ($v['validation'] === '3') {
                                                    $imgVal = '<img src="'.BASE_IMG.'puce-orange.png" title="'.$this->doorGets->__('En attente de modération').'" />';
                                                }
                                             ?>
                                            <li class="list-group-item">
                                                <a href="?controller=comment&action=select&id=<?php echo $v['id']; ?>">
                                                    <h4>
                                                      <?php echo $imgVal; ?> <?php echo $this->doorGets->_truncate($v['nom']); ?> <small>(<?php echo $this->doorGets->_truncate($v['email']); ?>)</small>
                                                    </h4>
                                                    <p><?php echo $this->doorGets->_truncate($v['comment']); ?></p>
                                                    <div class="text-right">
                                                        <small><?php echo GetDate::in($v['date_creation'],1,$this->doorGets->myLanguage); ?></small>
                                                    </div>
                                                </a>
                                            </li>
                                        <?php endforeach; ?>
                                            <li class="list-group-item text-right">
                                                <span><?php echo $this->doorGets->__("Total"); ?> : <?php echo $iComments; ?></span>
                                            </li>
                                        </ul>
                                    <?php else: ?>
                                        <div class="comment-center"><?php echo $this->doorGets->__("Il n'y a pas encore de commentaire"); ?>.</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($is_inbox_modo): ?>
                        <div class="col-md-12">
                            <div class="panel panel-default box-dash">
                                <div class="box-dash-title panel-heading">
                                    <a href="?controller=inbox">
                                        <b class="glyphicon glyphicon-envelope"></b>  <?php echo $this->doorGets->__("Message"); ?>
                                    </a>
                                </div>
                                <div class="panel-body box-dash-content">
                                    <?php if(!empty($lastInbox)): ?>
                                        <ul class="list-group">  
                                        <?php foreach($lastInbox as $v): ?>
                                            <?php 
                                                $imgVal = '<img src="'.BASE_IMG.'puce-orange.png" title="'.$this->doorGets->__('Non lu').'" />';
                                                if ($v['lu'] === '1') {
                                                    $imgVal = '<img src="'.BASE_IMG.'puce-verte.png" title="'.$this->doorGets->__('Lu').'" />';
                                                }
                                             ?>
                                            <li class="list-group-item">
                                                <a href="?controller=inbox&action=select&id=<?php echo $v['id']; ?>">
                                                    <h4 >
                                                      <?php echo $imgVal; ?> <?php echo $this->doorGets->_truncate($v['nom'],'30'); ?> - <?php echo $this->doorGets->_truncate($v['sujet'],'30'); ?> 
                                                      <small>(<?php echo $this->doorGets->_truncate($v['email']); ?>)</small>
                                                    </h4>
                                                    <p><?php echo $this->doorGets->_truncate($v['message']); ?></p>
                                                    <div class="text-right"><small><?php echo GetDate::in($v['date_creation'],1,$this->doorGets->myLanguage); ?></small></div>
                                                </a>
                                            </li>
                                        <?php endforeach; ?>
                                            <li class="list-group-item text-right">
                                                <span ><?php echo $this->doorGets->__("Total"); ?> : <?php echo $iInbox; ?></span>
                                            </li>
                                        </ul>
                                    <?php else: ?>
                                        <div class="comment-center"><?php echo $this->doorGets->__("Il n'y a pas encore de message"); ?>.</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(!empty($allModules)): ?>
                        
                        <div class="col-md-12">
                            <div class="panel panel-default box-dash">
                                <div class="box-dash-title panel-heading">
                                    <a href="?controller=modules">
                                        <b class="glyphicon glyphicon-asterisk"></b> <?php echo $this->doorGets->__("Module"); ?>
                                    </a>
                                </div>
                                <div class="panel-body box-dash-content">
                                    <?php if(!empty($allModules)): ?>
                                        <ul class="list-group">  
                                        <?php foreach($allModules as $v): ?>
                                            <?php 
                                                $imgVal = '<img src="'.BASE_IMG.'puce-verte.png" title="'.$this->doorGets->__('Active').'" />';
                                                if ($v['active'] === '0') {
                                                    $imgVal = '<img src="'.BASE_IMG.'puce-rouge.png" title="'.$this->doorGets->__('Désactivé').'" />';
                                                }
                                                $imgType = '<img src="'.$listeInfos[$v['type']]['image'].'" >';
                                             ?>
                                            <li class="list-group-item">
                                                <a href="<?php echo $v['url']; ?>" title="<?php echo $this->doorGets->__('Gérer le contenu'); ?>" style="display: block;">
                                                    <?php echo $imgVal; ?> <?php echo $imgType; ?> <?php echo $this->doorGets->_truncate($v['label']); ?>
                                                    <?php if(!empty($v['count'])): ?><span class="badge right"><?php echo $this->doorGets->_truncate($v['count']); ?></span><?php endif; ?>
                                                </a>
                                                
                                            </li>

                                        <?php endforeach; ?>
                                            <li class="list-group-item text-right">
                                                <span ><?php echo $this->doorGets->__("Total"); ?> [ <?php echo $this->doorGets->__("Module"); ?> : <?php echo $iModules; ?> - <?php echo $this->doorGets->__("Contenu"); ?> : <?php echo $iCountContents; ?> ]</span>
                                            </li>
                                        </ul>
                                    <?php else: ?>
                                        <div class="comment-center"><?php echo $this->doorGets->__("Il n'y a pas encore de module"); ?>.</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(!empty($modulesBlocks) || !empty($modulesGenforms)): ?>
                        
                        <div class="col-md-12">
                            <div class="panel panel-default box-dash">
                                <div class="box-dash-title panel-heading">
                                    <b class="glyphicon glyphicon-asterisk"></b> <?php echo $this->doorGets->__("Widgets"); ?>
                                </div>
                                <div class="panel-body box-dash-content">
                                    <ul class="list-group"> 
                                    <?php if(!empty($modulesBlocks)): ?>
                                         
                                        <?php foreach($modulesBlocks as $v): ?>
                                            <?php 
                                                $imgVal = '<img src="'.BASE_IMG.'puce-verte.png" title="'.$this->doorGets->__('Active').'" />';
                                                if ($v['active'] === '0') {
                                                    $imgVal = '<img src="'.BASE_IMG.'puce-rouge.png" title="'.$this->doorGets->__('Désactivé').'" />';
                                                }
                                                $imgType = '<img src="'.$listeInfos[$v['type']]['image'].'" >';
                                             ?>
                                            <li class="list-group-item">
                                                <a href="?controller=moduleblock&uri=<?php echo $v['uri']; ?>" title="<?php echo $this->doorGets->__('Gérer le contenu'); ?>" style="display: block;">
                                                    <?php echo $imgVal; ?> <?php echo $imgType; ?> <?php echo $this->doorGets->_truncate($v['label']); ?>
                                                </a>
                                            </li>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                    <?php if(!empty($modulesGenforms)): ?> 
                                        <?php foreach($modulesGenforms as $v): ?>
                                            <?php 
                                                $imgVal = '<img src="'.BASE_IMG.'puce-verte.png" title="'.$this->doorGets->__('Active').'" />';
                                                if ($v['active'] === '0') {
                                                    $imgVal = '<img src="'.BASE_IMG.'puce-rouge.png" title="'.$this->doorGets->__('Désactivé').'" />';
                                                }
                                                $imgType = '<img src="'.$listeInfos[$v['type']]['image'].'" >';
                                             ?>
                                            <li class="list-group-item">
                                                <a href="?controller=modulegenform&uri=<?php echo $v['uri']; ?>" title="<?php echo $this->doorGets->__('Gérer le contenu'); ?>" style="display: block;">
                                                    <?php echo $imgVal; ?> <?php echo $imgType; ?> <?php echo $this->doorGets->_truncate($v['label']); ?>
                                                    <?php if(!empty($v['count'])): ?><span class="badge right"><?php echo $this->doorGets->_truncate($v['count']); ?></span><?php endif; ?>
                                                </a>
                                            </li>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                    </ul>
                                    <?php if(empty($modulesGenforms) && empty($modulesBlocks)): ?> 
                                        <div class="comment-center"><?php echo $this->doorGets->__("Il n'y a pas encore de contenu"); ?>.</div>
                                    <?php endif; ?>
                                </div>
                                <div class="panel-footer text-right">
                                    <span><?php echo $this->doorGets->__("Total"); ?> : <?php echo $iModulesBlocks + $iModulesGenforms; ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div> 
            </div>
        </div>
        
    </div>

</div>
<script type="text/javascript">
  
    $( ".sortable-dash" ).sortable();
    $( ".sortable-dash" ).disableSelection();

    function checkHistory() {
        $.ajax({
            url: '<?php echo $urlHistory; ?>',
            dataType: 'json',
        })
        .done(function(data) {
            console.log(data.data);
            if (data.data.length > 0) {

                $.each(data.data, function(key,value){

                    $('#show-history .list-group').prepend('<li class="list-group-item"><a href="' + value.url + '">' + value.url + ' : ' + value.time + '</a></li>');
                });
            }
            
        });      
    }

    
    window.setInterval(function(){
        //checkHistory();
    }, 5000);
</script>
