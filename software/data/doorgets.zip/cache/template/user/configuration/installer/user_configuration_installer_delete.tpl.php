<?php 

/*******************************************************************************
/*******************************************************************************
    doorGets 7.0 - 31, August 2015
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2015 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/t/en/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/



?>
<legend>
        <?php echo $translate->l("Supprimer un installer"); ?>
</legend>
<div class="text-center">
    <?php echo $form->open('post');  echo $form->input('','delete','hidden','1');  echo $this->getFileName(); ?>
    <div class="separateur-tb"></div>
    <div class="action-bottom-inworks text-center" style="display: none;">
        <img src="<?php echo BASE_IMG.'loader.gif'; ?>" class="icon-image" style="width:25px;height: 25px;vertical-align: middle;">
        <?php echo $translate->l("Suppréssion en cours"); ?>...<?php echo $translate->l("Veuillez patienter"); ?>...
    </div>
    <div class="action-bottom-form text-center">
        <?php echo $form->submit($translate->l("Supprimer"),'','btn btn-danger bnt-lg'); ?>
        
    </div>
    <?php echo $form->close(); ?>
</div>
<script type="text/javascript">
  $("#installer_delete_submit").click(function() {
    
      $(".action-bottom-inworks").fadeIn();
      $(".action-bottom-form").fadeOut();
      $(".doorGets-comebackform").fadeOut();
      
  });
</script>