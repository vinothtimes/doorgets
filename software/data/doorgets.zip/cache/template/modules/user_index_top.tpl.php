<?php 

/*******************************************************************************
/*******************************************************************************
    doorGets 7.0 - 31, August 2015
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2015 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/t/en/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


?>
<legend>
    <a href="?controller=module<?php echo $moduleInfos['type']; ?>&uri=<?php echo $moduleInfos['uri']; ?>&lg=<?php echo $lgActuel; ?>"><img src="<?php echo BASE_IMG.'mod_'.$moduleInfos['type'].'.png'; ?>" title="<?php echo $moduleInfos['nom']; ?>" class="doorGets-img-ico px25" /> <?php echo $moduleInfos['nom']; ?></a> 
    <?php if($is_modules_modo): ?>
        <span class="create" ><a  href="?controller=modules&action=editblog&id=<?php echo $moduleInfos['id']; ?>&lg=<?php echo $lgActuel; ?>"><b class="glyphicon glyphicon-cog"></b> <?php echo $this->doorGets->__('Paramètres'); ?></a></span>
    <?php endif;  if(!($isLimited && $countContents >= $isLimited)): ?>
        <span class="create" ><a href="?controller=module<?php echo $moduleInfos['type']; ?>&uri=<?php echo $this->doorGets->Uri; ?>&action=add"class="violet" ><b class="glyphicon glyphicon-plus"></b>  <?php echo $this->doorGets->__('Ajouter'); ?></a></span>
    <?php endif;  if($is_modo): ?>
        <span class="create" ><?php echo $this->doorGets->genLangueMenuAdmin(); ?></span>
    <?php endif; ?>
</legend>