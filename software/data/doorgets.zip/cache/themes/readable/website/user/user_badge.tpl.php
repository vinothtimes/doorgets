<?php 

/*******************************************************************************
/*******************************************************************************
    doorGets 7.0 - 31, August 2015
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2015 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/t/en/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


?>
<!-- doorGets:start:user/user_badge -->
<div class="author-badge row">
    <?php if(!empty($networks)): ?>
    <div class="col-md-12 author-badge-follow">
        <ul class="list-inline">
            <li><?php echo $this->__("Suivre"); ?> <?php echo $_lastname; ?>:</li>
            <?php foreach($networks as $url_network => $url_image):  if(!empty($url_network)): ?>
                <li><a href="<?php echo $url_network; ?>" title="<?php echo $url_network; ?>" target="blank"><img src="<?php echo $url_image; ?>" alt="<?php echo $url_network; ?>" /></a></li>
                <?php endif; ?>
            <?php endforeach; ?>
        </ul> 
    </div>
    <?php endif; ?>
    <div class="col-sm-6 col-md-2">
        <img src="<?php echo URL.'data/users/'.$profile['avatar']; ?>" class="img-circle img-responsive img-author-badge">
    </div>
    <div class="col-sm-6 col-md-10">
        <h3><a href="<?php echo URL.'u/'.strtolower($profile['pseudo']); ?>"><?php echo $_name; ?></a></h3>
        <p><?php echo $_description; ?></p>
    </div>
</div>
<!-- doorGets:end:user/user_badge -->
