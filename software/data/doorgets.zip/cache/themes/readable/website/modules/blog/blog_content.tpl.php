<?php 

/*******************************************************************************
/*******************************************************************************
    doorGets 7.0 - 31, August 2015
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2015 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/t/en/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

 
 /*
  * Variables :
  *
        $isContent['id_content'] => $id_content
        $isContent['categorie'] => $categorie
        $isContent['titre' => $titre   
        $isContent['description'] => $description
        $isContent['uri'] => $uri
        $isContent['date_creation'] => $date_creation
        $isContent['article'] => $article

 */

?>
<!-- doorGets:start:modules/news/news_content -->
<div class="doorGets-news-content doorGets-module-<?php echo $Website->getModule(); ?>">
    <div class="row">
        <div class="col-md-9">
            <?php if($this->userPrivilege['add']): ?>
            <div class="btn-group pull-right btn-add-content">
                <a href="<?php echo $urlAdd; ?>" class="btn btn-success btn-large">
                    <b class="glyphicon glyphicon-plus"></b> 
                    <span><?php echo $Website->__('Créer un article'); ?></span>
                </a>
            </div>
            <?php endif; ?>
            <ol class="breadcrumb">
                
                <li><a href="<?php echo BASE_URL; ?>?<?php echo $Website->getModule(); ?>"><?php echo $labelModule; ?></a></li>
            </ol>
            <?php if(
                ( !$this->modulePrivilege['public_module'] && $this->userPrivilege['show'] )
                || $this->modulePrivilege['public_module']
            ): ?>
            <div class="doorGets-listing-contents left">
                <?php if(!empty($isContent)): ?>
                    <?php if($this->userPrivilege['edit'] || $this->userPrivilege['delete'] || $this->userPrivilege['modo'] ): ?>
                    <div class="btn-group navbar-right pull-right">
                        <a class="btn btn-default dropdown-toggle" data-toggle="dropdown" href="#">
                            <b  class="glyphicon glyphicon-cog"></b> <?php echo $Website->__('Action'); ?>
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                            <?php if( $this->userPrivilege['edit'] || $this->userPrivilege['modo'] ): ?>
                                <li><a href="<?php echo $urlEdition; ?>" class="navbut"><b class="glyphicon glyphicon-pencil"></b> <?php echo $Website->__('Modifier'); ?></a></li>
                            <?php endif; ?>
                            <?php if( $this->userPrivilege['delete'] || $this->userPrivilege['modo'] ): ?>
                                <li class="divider"></li>
                                <li><a href="<?php echo $urlDelete; ?>" class="navbut"><b class="glyphicon glyphicon-remove"></b> <span><?php echo $Website->__('Supprimer'); ?></span></a></li>                            
                            <?php endif; ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    <h2><?php echo $isContent['title']; ?></h2>
                    <div class="infos-content-title">
                        <?php if(!empty($linksToCategories)): ?><span class="right"> | <?php echo $linksToCategories; ?></span><?php endif; ?>
                    </div>
                    <div>
                        <img src="<?php echo BASE; ?>data/<?php echo $Website->getRealUri($Website->getModule()); ?>/<?php echo $isContent['image']; ?>" class="img-responsive  img-blog-content" />
                        <?php echo $isContent['article']; ?>
                    </div>
                    <?php if(!empty($isContent['image_gallery'])): ?>
                    <div class="magnificpopup-parent-container">
                        <h3>
                        <?php if(count($isContent['image_gallery']) > 1): ?>
                            <?php echo $Website->__('Image associées'); ?>
                        <?php else: ?>
                            <?php echo $Website->__('Image associée'); ?>
                        <?php endif; ?>
                        </h3>
                        <?php foreach($isContent['image_gallery'] as $pathFile): ?>
                            <a href="<?php echo URL.'data/'.$Website->getModule().'/'.$pathFile; ?>"><img src="<?php echo URL.'data/'.$Website->getModule().'/'.$pathFile; ?>" alt="<?php echo URL.'data/'.$Website->getModule().'/'.$pathFile; ?>" title="<?php echo URL.'data/'.$Website->getModule().'/'.$pathFile; ?>"></a>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                    <?php if($moduleInfo[$Module]['all']['author_badge'] && $isContent['author_badge']): ?>
                        <?php echo $Website->getHtmlBadge($isContent['id_user']); ?>
                    <?php endif; ?>
                    <?php if($sharethis): ?>
                    <div class="box-sharethis">
                        <?php echo $Website->getHtmlShareThis(); ?>
                    </div>
                    <?php endif; ?>
                    
                    <?php if($comments): ?>
                    <div class="box-comment-listing">
                        <?php echo $Website->getHtmlModuleComments(); ?>
                    </div>
                    <div class="box-comments">
                        <?php echo $Website->getHtmlComment(); ?>
                    </div>
                    <?php endif; ?>
                    
                    <?php if($facebook): ?>
                    <div class="box-facebook">
                        <?php echo $Website->getHtmlCommentFacebook(); ?>
                    </div> 
                    <?php endif; ?>
                   
                    <?php if($disqus): ?>
                    <div class="box-disqus">   
                        <?php echo $Website->getHtmlCommentDisqus(); ?>
                    </div>
                    <?php endif; ?>
                    
                    <div class="content-next-previous">
                        <ul class="pager">
                            <li class="previous">
                                <?php if(!empty($prevContent)): ?><a href="<?php echo $prevContent['url']; ?>">&larr; <?php echo $prevContent['label']; ?></a><?php endif; ?>
                            </li>
                            <li class="next">
                                <?php if(!empty($nexContent)): ?><a href="<?php echo $nexContent['url']; ?>"><?php echo $nexContent['label']; ?> &rarr;</a><?php endif; ?>
                            </li>
                        </ul>
                    </div>
                    
                <?php endif; ?>
            </div>
            <?php elseif(empty($Website->isUser)): ?>
                <div class="alert alert-danger">
                    <?php echo $Website->__('Vous devez vous connecter pour afficher ce contenu'); ?> : <a href="<?php echo $this->loginUrl; ?>&back=<?php echo urlencode($Website->getCurrentUrl()); ?>">Se connecter</a> ou <a href="<?php echo $this->registerUrl; ?>&back=<?php echo urlencode($Website->getCurrentUrl()); ?>">S'inscrire</a>
                </div>
            <?php else: ?>
                <div class="alert alert-danger">
                    <?php echo $Website->__('Vous ne pouvez pas voir ce contenu'); ?>
                </div>
            <?php endif; ?>

        </div>
        <div class="col-md-3">
            <?php echo $Website->getHtmlModuleSearch($q); ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                  <a href="<?php echo BASE_URL.'?'.$Website->getModule(); ?>"><h3 class="panel-title"><?php echo $Website->__('Catégories'); ?></h3></a>
                </div>
                <div class="panel-body">
                  <?php echo $Website->getHtmlModuleCategories(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- doorGets:end:modules/news/news_content -->
