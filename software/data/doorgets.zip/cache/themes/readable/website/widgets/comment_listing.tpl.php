<?php 

/*******************************************************************************
/*******************************************************************************
    doorGets 7.0 - 31, August 2015
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2015 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/t/en/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


 /*
  * Variables :
  * 
        $isModuleComments
        
    */
 
    $position = $countComments;
    
?>
<!-- doorGets:start:widgets/comment_listing -->
<?php if(!empty($this->configWeb['m_comment'])): ?>
<div id="comments">
    <div class="m-comment-title">
        <span>
            <strong>
                <?php echo $countComments; ?> <?php if($countComments > 1):  echo $this->__('commentaires');  else:  echo $this->__('commentaire');  endif; ?>
            </strong>
        </span>
    </div>
    <?php if(!empty($countComments)): ?>
        <?php for($i=0;$i<$countComments;$i++): ?>
            <?php $date = GetDate::in($isModuleComments[$i]['date_creation'],1,$this->myLanguage); ?>
            <div class="m-comment" >
                <span ><b><?php echo $isModuleComments[$i]['nom']; ?></b> <small class="right"><?php echo $date; ?></small></span>
                <div class="comment-content" >
                <?php echo $isModuleComments[$i]['comment']; ?>
                </div>
            </div>
            <?php $position--; ?>
        <?php endfor;  endif; ?>

</div>
<?php endif; ?>
<!-- doorGets:end:widgets/comment_listing -->
