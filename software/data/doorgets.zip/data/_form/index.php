<?php

header("Location:../");
exit();